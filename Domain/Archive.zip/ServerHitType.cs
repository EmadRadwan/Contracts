﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ServerHitType
{
    public ServerHitType()
    {
        ServerHitBins = new HashSet<ServerHitBin>();
        ServerHits = new HashSet<ServerHit>();
    }

    public string HitTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<ServerHitBin> ServerHitBins { get; set; }
    public ICollection<ServerHit> ServerHits { get; set; }
}