﻿using System;

namespace Domain;

public class PartyRateNew
{
    public string PartyId { get; set; }
    public string RateTypeId { get; set; }
    public string DefaultRate { get; set; }
    public double? PercentageUsed { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public RateType RateType { get; set; }
}