﻿using System;

namespace Domain;

public class ProductStoreVendorShipment
{
    public string ProductStoreId { get; set; }
    public string VendorPartyId { get; set; }
    public string ShipmentMethodTypeId { get; set; }
    public string CarrierPartyId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party CarrierParty { get; set; }
    public ProductStore ProductStore { get; set; }
    public ShipmentMethodType ShipmentMethodType { get; set; }
    public Party VendorParty { get; set; }
}