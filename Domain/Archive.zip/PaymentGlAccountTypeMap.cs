﻿using System;

namespace Domain;

public class PaymentGlAccountTypeMap
{
    public string PaymentTypeId { get; set; }
    public string OrganizationPartyId { get; set; }
    public string GlAccountTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public GlAccountType GlAccountType { get; set; }
    public Party OrganizationParty { get; set; }
    public PaymentType PaymentType { get; set; }
}