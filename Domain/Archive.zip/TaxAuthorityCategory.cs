﻿using System;

namespace Domain;

public class TaxAuthorityCategory
{
    public string TaxAuthGeoId { get; set; }
    public string TaxAuthPartyId { get; set; }
    public string ProductCategoryId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductCategory ProductCategory { get; set; }
    public TaxAuthority TaxAuth { get; set; }
}