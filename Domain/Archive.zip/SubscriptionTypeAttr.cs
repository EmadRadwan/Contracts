﻿using System;

namespace Domain;

public class SubscriptionTypeAttr
{
    public string SubscriptionTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SubscriptionType SubscriptionType { get; set; }
}