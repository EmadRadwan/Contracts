﻿using System;

namespace Domain;

public class WorkEffortDeliverableProd
{
    public string WorkEffortId { get; set; }
    public string DeliverableId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Deliverable Deliverable { get; set; }
    public WorkEffort WorkEffort { get; set; }
}