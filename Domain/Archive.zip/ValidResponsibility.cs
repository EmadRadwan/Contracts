﻿using System;

namespace Domain;

public class ValidResponsibility
{
    public string EmplPositionTypeId { get; set; }
    public string ResponsibilityTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public EmplPositionType EmplPositionType { get; set; }
    public ResponsibilityType ResponsibilityType { get; set; }
}