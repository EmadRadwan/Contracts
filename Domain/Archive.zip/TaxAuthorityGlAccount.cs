﻿using System;

namespace Domain;

public class TaxAuthorityGlAccount
{
    public string TaxAuthGeoId { get; set; }
    public string TaxAuthPartyId { get; set; }
    public string OrganizationPartyId { get; set; }
    public string GlAccountId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public GlAccount GlAccount { get; set; }
    public Party OrganizationParty { get; set; }
    public TaxAuthority TaxAuth { get; set; }
}