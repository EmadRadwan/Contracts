﻿using System;

namespace Domain;

public class ProductPromoCodeEmail
{
    public string ProductPromoCodeId { get; set; }
    public string EmailAddress { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductPromoCode ProductPromoCode { get; set; }
}