﻿using System;

namespace Domain;

public class TaxAuthorityAssoc
{
    public string TaxAuthGeoId { get; set; }
    public string TaxAuthPartyId { get; set; }
    public string ToTaxAuthGeoId { get; set; }
    public string ToTaxAuthPartyId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string TaxAuthorityAssocTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public TaxAuthority TaxAuth { get; set; }
    public TaxAuthorityAssocType TaxAuthorityAssocType { get; set; }
    public TaxAuthority ToTaxAuth { get; set; }
}