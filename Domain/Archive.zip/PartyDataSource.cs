﻿using System;

namespace Domain;

public class PartyDataSource
{
    public string PartyId { get; set; }
    public string DataSourceId { get; set; }
    public DateTime FromDate { get; set; }
    public string VisitId { get; set; }
    public string Comments { get; set; }
    public string IsCreate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public DataSource DataSource { get; set; }
    public Party Party { get; set; }
}