﻿using System;

namespace Domain;

public class UserLoginSession
{
    public string UserLoginId { get; set; }
    public DateTime? SavedDate { get; set; }
    public string SessionData { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin UserLogin { get; set; }
}