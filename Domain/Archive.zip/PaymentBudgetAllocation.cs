﻿using System;

namespace Domain;

public class PaymentBudgetAllocation
{
    public string BudgetId { get; set; }
    public string BudgetItemSeqId { get; set; }
    public string PaymentId { get; set; }
    public decimal? Amount { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Budget Budget { get; set; }
    public Payment Payment { get; set; }
}