﻿using System;

namespace Domain;

public class PortalPagePortlet
{
    public string PortalPageId { get; set; }
    public string PortalPortletId { get; set; }
    public string PortletSeqId { get; set; }
    public string ColumnSeqId { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PortalPage PortalPage { get; set; }
    public PortalPortlet PortalPortlet { get; set; }
}