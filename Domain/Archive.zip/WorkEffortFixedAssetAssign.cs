﻿using System;

namespace Domain;

public class WorkEffortFixedAssetAssign
{
    public string WorkEffortId { get; set; }
    public string FixedAssetId { get; set; }
    public string StatusId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string AvailabilityStatusId { get; set; }
    public decimal? AllocatedCost { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public StatusItem AvailabilityStatus { get; set; }
    public FixedAsset FixedAsset { get; set; }
    public StatusItem Status { get; set; }
    public WorkEffort WorkEffort { get; set; }
}