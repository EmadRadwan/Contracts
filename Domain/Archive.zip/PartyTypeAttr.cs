﻿using System;

namespace Domain;

public class PartyTypeAttr
{
    public string PartyTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyType PartyType { get; set; }
}