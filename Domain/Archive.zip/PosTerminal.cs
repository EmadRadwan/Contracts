﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PosTerminal
{
    public PosTerminal()
    {
        PosTerminalLogs = new HashSet<PosTerminalLog>();
        PosTerminalStates = new HashSet<PosTerminalState>();
    }

    public string PosTerminalId { get; set; }
    public Guid FacilityId { get; set; }
    public string PushEntitySyncId { get; set; }
    public string TerminalName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<PosTerminalLog> PosTerminalLogs { get; set; }
    public ICollection<PosTerminalState> PosTerminalStates { get; set; }
}