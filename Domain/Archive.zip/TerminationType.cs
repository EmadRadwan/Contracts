﻿using System;
using System.Collections.Generic;

namespace Domain;

public class TerminationType
{
    public TerminationType()
    {
        InverseParentType = new HashSet<TerminationType>();
    }

    public string TerminationTypeId { get; set; }
    public string ParentTypeId { get; set; }
    public string HasTable { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public TerminationType ParentType { get; set; }
    public ICollection<TerminationType> InverseParentType { get; set; }
}