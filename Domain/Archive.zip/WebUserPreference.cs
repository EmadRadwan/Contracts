﻿using System;

namespace Domain;

public class WebUserPreference
{
    public string UserLoginId { get; set; }
    public string PartyId { get; set; }
    public string VisitId { get; set; }
    public string WebPreferenceTypeId { get; set; }
    public string WebPreferenceValue { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public AppUserLogin UserLogin { get; set; }
    public WebPreferenceType WebPreferenceType { get; set; }
}