﻿using System;

namespace Domain;

public class ProductStoreGroupRole
{
    public string ProductStoreGroupId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyRole PartyRole { get; set; }
    public ProductStoreGroup ProductStoreGroup { get; set; }
}