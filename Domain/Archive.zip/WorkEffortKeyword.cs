﻿using System;

namespace Domain;

public class WorkEffortKeyword
{
    public string WorkEffortId { get; set; }
    public string Keyword { get; set; }
    public decimal? RelevancyWeight { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffort WorkEffort { get; set; }
}