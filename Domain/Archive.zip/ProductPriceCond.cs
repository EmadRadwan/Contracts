﻿using System;

namespace Domain;

public class ProductPriceCond
{
    public string ProductPriceRuleId { get; set; }
    public string ProductPriceCondSeqId { get; set; }
    public string InputParamEnumId { get; set; }
    public string OperatorEnumId { get; set; }
    public string CondValue { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Enumeration InputParamEnum { get; set; }
    public Enumeration OperatorEnum { get; set; }
    public ProductPriceRule ProductPriceRule { get; set; }
}