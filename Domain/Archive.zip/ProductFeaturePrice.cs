﻿using System;

namespace Domain;

public class ProductFeaturePrice
{
    public string ProductFeatureId { get; set; }
    public string ProductPriceTypeId { get; set; }
    public string CurrencyUomId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? Price { get; set; }
    public DateTime? CreatedDate { get; set; }
    public string CreatedByUserLogin { get; set; }
    public DateTime? LastModifiedDate { get; set; }
    public string LastModifiedByUserLogin { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin CreatedByUserLoginNavigation { get; set; }
    public Uom CurrencyUom { get; set; }
    public AppUserLogin LastModifiedByUserLoginNavigation { get; set; }
    public ProductPriceType ProductPriceType { get; set; }
}