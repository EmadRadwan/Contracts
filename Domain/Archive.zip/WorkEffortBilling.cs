﻿using System;

namespace Domain;

public class WorkEffortBilling
{
    public string WorkEffortId { get; set; }
    public string InvoiceId { get; set; }
    public string InvoiceItemSeqId { get; set; }
    public double? Percentage { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InvoiceItem InvoiceI { get; set; }
    public WorkEffort WorkEffort { get; set; }
}