﻿using System;

namespace Domain;

public class WebSiteRole
{
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public string WebSiteId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyRole PartyRole { get; set; }
    public WebSite WebSite { get; set; }
}