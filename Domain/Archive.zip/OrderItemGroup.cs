﻿using System;
using System.Collections.Generic;

namespace Domain;

public class OrderItemGroup
{
    public OrderItemGroup()
    {
        InverseOrderItemGroupNavigation = new HashSet<OrderItemGroup>();
        OrderItems = new HashSet<OrderItem>();
    }

    public string OrderId { get; set; }
    public string OrderItemGroupSeqId { get; set; }
    public string ParentGroupSeqId { get; set; }
    public string GroupName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public OrderItemGroup OrderItemGroupNavigation { get; set; }
    public ICollection<OrderItemGroup> InverseOrderItemGroupNavigation { get; set; }
    public ICollection<OrderItem> OrderItems { get; set; }
}