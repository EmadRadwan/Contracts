﻿using System;

namespace Domain;

public class SecurityGroupPermission_OLD
{
    public string GroupId { get; set; }
    public string PermissionId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SecurityGroup Group { get; set; }
}