﻿using System;
using System.Collections.Generic;

namespace Domain;

public class WorkEffortAssoc
{
    public WorkEffortAssoc()
    {
        WorkEffortAssocAttributes = new HashSet<WorkEffortAssocAttribute>();
    }

    public string WorkEffortIdFrom { get; set; }
    public string WorkEffortIdTo { get; set; }
    public string WorkEffortAssocTypeId { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffortAssocType WorkEffortAssocType { get; set; }
    public WorkEffort WorkEffortIdFromNavigation { get; set; }
    public WorkEffort WorkEffortIdToNavigation { get; set; }
    public ICollection<WorkEffortAssocAttribute> WorkEffortAssocAttributes { get; set; }
}