﻿using System;

namespace Domain;

public class PartyClassification
{
    public string PartyId { get; set; }
    public string PartyClassificationGroupId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public PartyClassificationGroup PartyClassificationGroup { get; set; }
}