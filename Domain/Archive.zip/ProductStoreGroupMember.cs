﻿using System;

namespace Domain;

public class ProductStoreGroupMember
{
    public string ProductStoreId { get; set; }
    public string ProductStoreGroupId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductStore ProductStore { get; set; }
    public ProductStoreGroup ProductStoreGroup { get; set; }
}