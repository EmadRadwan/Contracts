﻿using System;

namespace Domain;

public class RequirementTypeAttr
{
    public string RequirementTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public RequirementType RequirementType { get; set; }
}