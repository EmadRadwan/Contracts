﻿using System;
using System.Collections.Generic;

namespace Domain;

public class SegmentGroupType
{
    public SegmentGroupType()
    {
        SegmentGroups = new HashSet<SegmentGroup>();
    }

    public string SegmentGroupTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<SegmentGroup> SegmentGroups { get; set; }
}