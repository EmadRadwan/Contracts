using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;

namespace Domain;

public class SecurityGroup : IdentityRole
{
    public SecurityGroup()
    {
        PartyRelationships = new HashSet<PartyRelationship>();
        PortalPages = new HashSet<PortalPage>();
        ProtectedViews = new HashSet<ProtectedView>();
        SecurityGroupPermissions = new HashSet<SecurityGroupPermission>();
        UserLoginSecurityGroups = new HashSet<UserLoginSecurityGroup>();
    }

    public string GroupId { get; set; }
    //public string GroupName { get; set; }
    public string? Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }


    //  IdentityRole
    // Id
    // Name
    // NormalizedName
    // ConcurrencyStamp

    public ICollection<PartyRelationship> PartyRelationships { get; set; }
    public ICollection<PortalPage> PortalPages { get; set; }
    public ICollection<ProtectedView> ProtectedViews { get; set; }
    public ICollection<SecurityGroupPermission> SecurityGroupPermissions { get; set; }
    public ICollection<UserLoginSecurityGroup> UserLoginSecurityGroups { get; set; }


    public ICollection<ApplicationUserRole> UserRoles { get; set; }
}