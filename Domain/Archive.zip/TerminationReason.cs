﻿using System;

namespace Domain;

public class TerminationReason
{
    public string TerminationReasonId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
}