﻿using System;

namespace Domain;

public class OrderShipment
{
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string ShipGroupSeqId { get; set; }
    public string ShipmentId { get; set; }
    public string ShipmentItemSeqId { get; set; }
    public decimal? Quantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public Shipment Shipment { get; set; }
}