﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductPromoRule
{
    public ProductPromoRule()
    {
        ProductPromoActions = new HashSet<ProductPromoAction>();
        ProductPromoConds = new HashSet<ProductPromoCond>();
    }

    public string ProductPromoId { get; set; }
    public string ProductPromoRuleId { get; set; }
    public string RuleName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductPromo ProductPromo { get; set; }
    public ICollection<ProductPromoAction> ProductPromoActions { get; set; }
    public ICollection<ProductPromoCond> ProductPromoConds { get; set; }
}