﻿using System;

namespace Domain;

public class WorkEffortStatu
{
    public string WorkEffortId { get; set; }
    public string StatusId { get; set; }
    public DateTime StatusDatetime { get; set; }
    public string SetByUserLogin { get; set; }
    public string Reason { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin SetByUserLoginNavigation { get; set; }
    public StatusItem Status { get; set; }
    public WorkEffort WorkEffort { get; set; }
}