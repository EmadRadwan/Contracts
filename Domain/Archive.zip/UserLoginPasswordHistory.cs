﻿using System;

namespace Domain;

public class UserLoginPasswordHistory
{
    public string UserLoginId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string CurrentPassword { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin UserLogin { get; set; }
}