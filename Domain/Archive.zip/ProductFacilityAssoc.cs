﻿using System;

namespace Domain;

public class ProductFacilityAssoc
{
    public Guid ProductId { get; set; }
    public string FacilityId { get; set; }
    public string FacilityIdTo { get; set; }
    public string FacilityAssocTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public decimal? TransitTime { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Facility Facility { get; set; }
    public FacilityAssocType FacilityAssocType { get; set; }
    public Facility FacilityIdToNavigation { get; set; }
    public Product Product { get; set; }
}