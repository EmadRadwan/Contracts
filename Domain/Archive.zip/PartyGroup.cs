﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PartyGroup
{
    public PartyGroup()
    {
        PartyInvitationGroupAssocs = new HashSet<PartyInvitationGroupAssoc>();
    }

    public string PartyId { get; set; }
    public string GroupName { get; set; }
    public string? GroupNameLocal { get; set; }
    public string? OfficeSiteName { get; set; }
    public decimal? AnnualRevenue { get; set; }
    public decimal? NumEmployees { get; set; }
    public string? TickerSymbol { get; set; }
    public string? Comments { get; set; }
    public string? LogoImageUrl { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party? Party { get; set; }
    public Affiliate? Affiliate { get; set; }
    public ICollection<PartyInvitationGroupAssoc> PartyInvitationGroupAssocs { get; set; }
}