﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ReturnHeaderType
{
    public ReturnHeaderType()
    {
        InverseParentType = new HashSet<ReturnHeaderType>();
        ReturnHeaders = new HashSet<ReturnHeader>();
        ReturnItemTypeMaps = new HashSet<ReturnItemTypeMap>();
    }

    public string ReturnHeaderTypeId { get; set; }
    public string ParentTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ReturnHeaderType ParentType { get; set; }
    public ICollection<ReturnHeaderType> InverseParentType { get; set; }
    public ICollection<ReturnHeader> ReturnHeaders { get; set; }
    public ICollection<ReturnItemTypeMap> ReturnItemTypeMaps { get; set; }
}