﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductPriceAction
{
    public ProductPriceAction()
    {
        OrderItemPriceInfoes = new HashSet<OrderItemPriceInfo>();
    }

    public string ProductPriceRuleId { get; set; }
    public string ProductPriceActionSeqId { get; set; }
    public string ProductPriceActionTypeId { get; set; }
    public decimal? Amount { get; set; }
    public string RateCode { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductPriceActionType ProductPriceActionType { get; set; }
    public ProductPriceRule ProductPriceRule { get; set; }
    public ICollection<OrderItemPriceInfo> OrderItemPriceInfoes { get; set; }
}