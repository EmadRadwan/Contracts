﻿using System;

namespace Domain;

public class SalaryStepNew
{
    public string SalaryStepSeqId { get; set; }
    public string PayGradeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? DateModified { get; set; }
    public decimal? Amount { get; set; }
    public string CreatedByUserLogin { get; set; }
    public string LastModifiedByUserLogin { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PayGrade PayGrade { get; set; }
}