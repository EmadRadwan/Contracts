﻿using System;

namespace Domain;

public class ProductSubscriptionResource
{
    public Guid ProductId { get; set; }
    public string SubscriptionResourceId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? PurchaseFromDate { get; set; }
    public DateTime? PurchaseThruDate { get; set; }
    public decimal? MaxLifeTime { get; set; }
    public string MaxLifeTimeUomId { get; set; }
    public decimal? AvailableTime { get; set; }
    public string AvailableTimeUomId { get; set; }
    public decimal? UseCountLimit { get; set; }
    public decimal? UseTime { get; set; }
    public string UseTimeUomId { get; set; }
    public string UseRoleTypeId { get; set; }
    public string AutomaticExtend { get; set; }
    public decimal? CanclAutmExtTime { get; set; }
    public string CanclAutmExtTimeUomId { get; set; }
    public decimal? GracePeriodOnExpiry { get; set; }
    public string GracePeriodOnExpiryUomId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Uom AvailableTimeUom { get; set; }
    public Uom CanclAutmExtTimeUom { get; set; }
    public Uom GracePeriodOnExpiryUom { get; set; }
    public Uom MaxLifeTimeUom { get; set; }
    public Product Product { get; set; }
    public SubscriptionResource SubscriptionResource { get; set; }
    public RoleType UseRoleType { get; set; }
    public Uom UseTimeUom { get; set; }
}