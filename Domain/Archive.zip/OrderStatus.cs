﻿using System;

namespace Domain;

public class OrderStatus
{
    public string OrderStatusId { get; set; }
    public string StatusId { get; set; }
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string OrderPaymentPreferenceId { get; set; }
    public DateTime? StatusDatetime { get; set; }
    public string StatusUserLogin { get; set; }
    public string ChangeReason { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public StatusItem Status { get; set; }
    public AppUserLogin StatusUserLoginNavigation { get; set; }
}