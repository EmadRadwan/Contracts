﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PaymentGatewayConfig
{
    public PaymentGatewayConfig()
    {
        ProductStorePaymentSettings = new HashSet<ProductStorePaymentSetting>();
    }

    public string PaymentGatewayConfigId { get; set; }
    public string PaymentGatewayConfigTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentGatewayConfigType PaymentGatewayConfigType { get; set; }
    public PaymentGatewayAuthorizeNet PaymentGatewayAuthorizeNet { get; set; }
    public PaymentGatewayClearCommerce PaymentGatewayClearCommerce { get; set; }
    public PaymentGatewayCyberSource PaymentGatewayCyberSource { get; set; }
    public PaymentGatewayEway PaymentGatewayEway { get; set; }
    public PaymentGatewayFirstData PaymentGatewayFirstData { get; set; }
    public PaymentGatewayOrbital PaymentGatewayOrbital { get; set; }
    public PaymentGatewayPayPal PaymentGatewayPayPal { get; set; }
    public PaymentGatewayPayflowPro PaymentGatewayPayflowPro { get; set; }
    public PaymentGatewaySagePay PaymentGatewaySagePay { get; set; }
    public PaymentGatewaySecurePay PaymentGatewaySecurePay { get; set; }
    public PaymentGatewayWorldPay PaymentGatewayWorldPay { get; set; }
    public ICollection<ProductStorePaymentSetting> ProductStorePaymentSettings { get; set; }
}