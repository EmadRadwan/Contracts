﻿using System;

namespace Domain;

public class ProductReview
{
    public string ProductReviewId { get; set; }
    public string ProductStoreId { get; set; }
    public Guid ProductId { get; set; }
    public string UserLoginId { get; set; }
    public string StatusId { get; set; }
    public string PostedAnonymous { get; set; }
    public DateTime? PostedDateTime { get; set; }
    public decimal? ProductRating { get; set; }
    public string ProductReview1 { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
    public ProductStore ProductStore { get; set; }
    public StatusItem Status { get; set; }
    public AppUserLogin UserLogin { get; set; }
}