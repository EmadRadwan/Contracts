﻿using System;

namespace Domain;

public class ServerHitBin
{
    public string ServerHitBinId { get; set; }
    public string ContentId { get; set; }
    public string HitTypeId { get; set; }
    public string ServerIpAddress { get; set; }
    public string ServerHostName { get; set; }
    public DateTime? BinStartDateTime { get; set; }
    public DateTime? BinEndDateTime { get; set; }
    public decimal? NumberHits { get; set; }
    public decimal? TotalTimeMillis { get; set; }
    public decimal? MinTimeMillis { get; set; }
    public decimal? MaxTimeMillis { get; set; }
    public string InternalContentId { get; set; }

    public ServerHitType HitType { get; set; }
}