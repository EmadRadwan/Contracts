﻿using System;
using System.Collections.Generic;

namespace Domain;

public class VarianceReason
{
    public VarianceReason()
    {
        InventoryItemVariances = new HashSet<InventoryItemVariance>();
        VarianceReasonGlAccounts = new HashSet<VarianceReasonGlAccount>();
    }

    public string VarianceReasonId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<InventoryItemVariance> InventoryItemVariances { get; set; }
    public ICollection<VarianceReasonGlAccount> VarianceReasonGlAccounts { get; set; }
}