﻿using System;

namespace Domain;

public class SupplierProduct
{
    public Guid ProductId { get; set; }
    public string PartyId { get; set; }
    public DateTime AvailableFromDate { get; set; }
    public DateTime? AvailableThruDate { get; set; }
    public string? SupplierPrefOrderId { get; set; }
    public string? SupplierRatingTypeId { get; set; }
    public decimal? StandardLeadTimeDays { get; set; }
    public decimal? MinimumOrderQuantity { get; set; }
    public decimal? OrderQtyIncrements { get; set; }
    public decimal? UnitsIncluded { get; set; }
    public string? QuantityUomId { get; set; }
    public string? AgreementId { get; set; }
    public string? AgreementItemSeqId { get; set; }
    public decimal? LastPrice { get; set; }
    public decimal? ShippingPrice { get; set; }
    public string? CurrencyUomId { get; set; }
    public string? SupplierProductName { get; set; }
    public Guid? SupplierProductId { get; set; }
    public string? CanDropShip { get; set; }
    public string? Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AgreementItem? AgreementI { get; set; }
    public Uom? CurrencyUom { get; set; }
    public Party? Party { get; set; }
    public Product? Product { get; set; }
    public Uom? QuantityUom { get; set; }
    public SupplierPrefOrder? SupplierPrefOrder { get; set; }
    public SupplierRatingType? SupplierRatingType { get; set; }
}