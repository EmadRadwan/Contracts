﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PaymentGroup
{
    public PaymentGroup()
    {
        PaymentGroupMembers = new HashSet<PaymentGroupMember>();
    }

    public string PaymentGroupId { get; set; }
    public string PaymentGroupTypeId { get; set; }
    public string PaymentGroupName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentGroupType PaymentGroupType { get; set; }
    public ICollection<PaymentGroupMember> PaymentGroupMembers { get; set; }
}