﻿using System;

namespace Domain;

public class ProductStorePaymentSetting
{
    public string ProductStoreId { get; set; }
    public string PaymentMethodTypeId { get; set; }
    public string PaymentServiceTypeEnumId { get; set; }
    public string PaymentService { get; set; }
    public string PaymentCustomMethodId { get; set; }
    public string PaymentGatewayConfigId { get; set; }
    public string PaymentPropertiesPath { get; set; }
    public string ApplyToAllProducts { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CustomMethod PaymentCustomMethod { get; set; }
    public PaymentGatewayConfig PaymentGatewayConfig { get; set; }
    public PaymentMethodType PaymentMethodType { get; set; }
    public Enumeration PaymentServiceTypeEnum { get; set; }
    public ProductStore ProductStore { get; set; }
}