﻿using System;
using System.Collections.Generic;

namespace Domain;

public class TechDataCalendarWeek
{
    public TechDataCalendarWeek()
    {
        TechDataCalendarExcWeeks = new HashSet<TechDataCalendarExcWeek>();
        TechDataCalendars = new HashSet<TechDataCalendar>();
    }

    public string CalendarWeekId { get; set; }
    public string Description { get; set; }
    public TimeSpan? MondayStartTime { get; set; }
    public double? MondayCapacity { get; set; }
    public TimeSpan? TuesdayStartTime { get; set; }
    public double? TuesdayCapacity { get; set; }
    public TimeSpan? WednesdayStartTime { get; set; }
    public double? WednesdayCapacity { get; set; }
    public TimeSpan? ThursdayStartTime { get; set; }
    public double? ThursdayCapacity { get; set; }
    public TimeSpan? FridayStartTime { get; set; }
    public double? FridayCapacity { get; set; }
    public TimeSpan? SaturdayStartTime { get; set; }
    public double? SaturdayCapacity { get; set; }
    public TimeSpan? SundayStartTime { get; set; }
    public double? SundayCapacity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<TechDataCalendarExcWeek> TechDataCalendarExcWeeks { get; set; }
    public ICollection<TechDataCalendar> TechDataCalendars { get; set; }
}