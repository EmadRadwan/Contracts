﻿using System;

namespace Domain;

public class PartyNeed
{
    public string PartyNeedId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public string PartyTypeId { get; set; }
    public string NeedTypeId { get; set; }
    public string CommunicationEventId { get; set; }
    public Guid ProductId { get; set; }
    public string ProductCategoryId { get; set; }
    public string VisitId { get; set; }
    public DateTime? DatetimeRecorded { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CommunicationEvent CommunicationEvent { get; set; }
    public NeedType NeedType { get; set; }
    public Party Party { get; set; }
    public PartyType PartyType { get; set; }
    public Product Product { get; set; }
    public ProductCategory ProductCategory { get; set; }
    public RoleType RoleType { get; set; }
}