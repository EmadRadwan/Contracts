﻿using System;

namespace Domain;

public class PosTerminalInternTx
{
    public string PosTerminalLogId { get; set; }
    public decimal? PaidAmount { get; set; }
    public string ReasonComment { get; set; }
    public string ReasonEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PosTerminalLog PosTerminalLog { get; set; }
    public Enumeration ReasonEnum { get; set; }
}