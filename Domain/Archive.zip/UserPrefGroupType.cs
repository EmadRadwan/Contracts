﻿using System;
using System.Collections.Generic;

namespace Domain;

public class UserPrefGroupType
{
    public UserPrefGroupType()
    {
        UserPreferences = new HashSet<UserPreference>();
    }

    public string UserPrefGroupTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<UserPreference> UserPreferences { get; set; }
}