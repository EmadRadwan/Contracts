﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PeriodType
{
    public PeriodType()
    {
        CustomTimePeriods = new HashSet<CustomTimePeriod>();
        PayHistories = new HashSet<PayHistory>();
        RateAmounts = new HashSet<RateAmount>();
    }

    public string PeriodTypeId { get; set; }
    public string Description { get; set; }
    public decimal? PeriodLength { get; set; }
    public string UomId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Uom Uom { get; set; }
    public ICollection<CustomTimePeriod> CustomTimePeriods { get; set; }
    public ICollection<PayHistory> PayHistories { get; set; }
    public ICollection<RateAmount> RateAmounts { get; set; }
}