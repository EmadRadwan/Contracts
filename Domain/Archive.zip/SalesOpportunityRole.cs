﻿using System;

namespace Domain;

public class SalesOpportunityRole
{
    public string SalesOpportunityId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public PartyRole PartyRole { get; set; }
    public RoleType RoleType { get; set; }
    public SalesOpportunity SalesOpportunity { get; set; }
}