﻿using System;

namespace Domain;

public class PicklistStatu
{
    public string PicklistId { get; set; }
    public DateTime StatusDate { get; set; }
    public string ChangedByUserLoginId { get; set; }
    public string StatusId { get; set; }
    public string StatusIdTo { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin ChangeByUserLogin { get; set; }
    public Picklist Picklist { get; set; }
    public StatusItem Status { get; set; }
    public StatusItem StatusIdToNavigation { get; set; }
}