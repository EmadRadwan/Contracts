﻿using System;
using System.Collections.Generic;

namespace Domain;

public class RejectionReason
{
    public RejectionReason()
    {
        ShipmentReceipts = new HashSet<ShipmentReceipt>();
    }

    public string RejectionId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<ShipmentReceipt> ShipmentReceipts { get; set; }
}