﻿using System;

namespace Domain;

public class ProductFacilityLocation
{
    public Guid ProductId { get; set; }
    public string FacilityId { get; set; }
    public string LocationSeqId { get; set; }
    public decimal? MinimumStock { get; set; }
    public decimal? MoveQuantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public FacilityLocation FacilityLocation { get; set; }
    public Product Product { get; set; }
}