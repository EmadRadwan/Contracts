﻿using System;

namespace Domain;

public class ProductPriceAutoNotice
{
    public string ProductPriceNoticeId { get; set; }
    public Guid FacilityId { get; set; }
    public DateTime? RunDate { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
}