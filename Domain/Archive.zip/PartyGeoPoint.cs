﻿using System;

namespace Domain;

public class PartyGeoPoint
{
    public string PartyId { get; set; }
    public string GeoPointId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public GeoPoint GeoPoint { get; set; }
    public Party Party { get; set; }
}