﻿using System;

namespace Domain;

public class PostalAddressBoundary
{
    public string ContactMechId { get; set; }
    public string GeoId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PostalAddress ContactMech { get; set; }
    public Geo Geo { get; set; }
}