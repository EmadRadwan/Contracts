﻿using System;

namespace Domain;

public class RequirementStatu
{
    public string RequirementId { get; set; }
    public string StatusId { get; set; }
    public DateTime? StatusDate { get; set; }
    public string ChangedByUserLoginId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin ChangeByUserLogin { get; set; }
    public Requirement Requirement { get; set; }
    public StatusItem Status { get; set; }
}