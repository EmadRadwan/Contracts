﻿using System;

namespace Domain;

public class WorkOrderItemFulfillment
{
    public string WorkEffortId { get; set; }
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string ShipGroupSeqId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public OrderItem OrderI { get; set; }
    public WorkEffort WorkEffort { get; set; }
}