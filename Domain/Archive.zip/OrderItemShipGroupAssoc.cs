﻿using System;

namespace Domain;

public class OrderItemShipGroupAssoc
{
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string ShipGroupSeqId { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? CancelQuantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public OrderItem OrderI { get; set; }
    public OrderItemShipGroup OrderItemShipGroup { get; set; }
}