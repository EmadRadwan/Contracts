﻿using System;

namespace Domain;

public class ProductPromoContent
{
    public string ProductPromoId { get; set; }
    public string ContentId { get; set; }
    public string ProductPromoContentTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public ProductPromo ProductPromo { get; set; }
    public ProductContentType ProductPromoContentType { get; set; }
}