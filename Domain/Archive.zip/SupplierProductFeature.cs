﻿using System;

namespace Domain;

public class SupplierProductFeature
{
    public string PartyId { get; set; }
    public string ProductFeatureId { get; set; }
    public string Description { get; set; }
    public string UomId { get; set; }
    public string IdCode { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public ProductFeature ProductFeature { get; set; }
    public Uom Uom { get; set; }
}