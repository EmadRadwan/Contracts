﻿using System;

namespace Domain;

public class ProdPromoCodeContactMech
{
    public string ProductPromoCodeId { get; set; }
    public string ContactMechId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMech ContactMech { get; set; }
    public ProductPromoCode ProductPromoCode { get; set; }
}