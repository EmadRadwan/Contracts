﻿using System;

namespace Domain;

public class SegmentGroupGeo
{
    public string SegmentGroupId { get; set; }
    public string GeoId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Geo Geo { get; set; }
    public SegmentGroup SegmentGroup { get; set; }
}