﻿using System;

namespace Domain;

public class ShoppingListItemSurvey
{
    public string ShoppingListId { get; set; }
    public string ShoppingListItemSeqId { get; set; }
    public string SurveyResponseId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ShoppingList ShoppingList { get; set; }
    public ShoppingListItem ShoppingListI { get; set; }
    public SurveyResponse SurveyResponse { get; set; }
}