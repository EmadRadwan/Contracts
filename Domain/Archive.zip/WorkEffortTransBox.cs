﻿using System;

namespace Domain;

public class WorkEffortTransBox
{
    public string ProcessWorkEffortId { get; set; }
    public string ToActivityId { get; set; }
    public string TransitionId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffort ProcessWorkEffort { get; set; }
}