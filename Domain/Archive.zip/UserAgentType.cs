﻿using System;
using System.Collections.Generic;

namespace Domain;

public class UserAgentType
{
    public UserAgentType()
    {
        UserAgents = new HashSet<UserAgent>();
    }

    public string UserAgentTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<UserAgent> UserAgents { get; set; }
}