﻿using System;

namespace Domain;

public class PicklistItem
{
    public string PicklistBinId { get; set; }
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string ShipGroupSeqId { get; set; }
    public string InventoryItemId { get; set; }
    public string ItemStatusId { get; set; }
    public decimal? Quantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InventoryItem InventoryItem { get; set; }
    public StatusItem ItemStatus { get; set; }
    public OrderItem OrderI { get; set; }
    public OrderItemShipGroup OrderItemShipGroup { get; set; }
    public PicklistBin PicklistBin { get; set; }
}