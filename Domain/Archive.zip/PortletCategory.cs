﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PortletCategory
{
    public PortletCategory()
    {
        PortletPortletCategories = new HashSet<PortletPortletCategory>();
    }

    public string PortletCategoryId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<PortletPortletCategory> PortletPortletCategories { get; set; }
}