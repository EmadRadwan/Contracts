﻿using System;

namespace Domain;

public class ReturnItemTypeMap
{
    public string ReturnItemMapKey { get; set; }
    public string ReturnHeaderTypeId { get; set; }
    public string ReturnItemTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ReturnHeaderType ReturnHeaderType { get; set; }
}