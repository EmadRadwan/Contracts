﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductFeatureApplType
{
    public ProductFeatureApplType()
    {
        InverseParentType = new HashSet<ProductFeatureApplType>();
        ProductFeatureAppls = new HashSet<ProductFeatureAppl>();
    }

    public string ProductFeatureApplTypeId { get; set; }
    public string ParentTypeId { get; set; }
    public string HasTable { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductFeatureApplType ParentType { get; set; }
    public ICollection<ProductFeatureApplType> InverseParentType { get; set; }
    public ICollection<ProductFeatureAppl> ProductFeatureAppls { get; set; }
}