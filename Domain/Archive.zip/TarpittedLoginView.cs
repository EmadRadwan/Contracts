﻿using System;

namespace Domain;

public class TarpittedLoginView
{
    public string ViewNameId { get; set; }
    public string UserLoginId { get; set; }
    public decimal? TarpitReleaseDateTime { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
}