﻿using System;
using System.Collections.Generic;

namespace Domain;

public class SurveyMultiResp
{
    public SurveyMultiResp()
    {
        SurveyMultiRespColumns = new HashSet<SurveyMultiRespColumn>();
    }

    public string SurveyId { get; set; }
    public string SurveyMultiRespId { get; set; }
    public string MultiRespTitle { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Survey Survey { get; set; }
    public ICollection<SurveyMultiRespColumn> SurveyMultiRespColumns { get; set; }
}