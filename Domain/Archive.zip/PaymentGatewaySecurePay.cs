﻿using System;

namespace Domain;

public class PaymentGatewaySecurePay
{
    public string PaymentGatewayConfigId { get; set; }
    public string MerchantId { get; set; }
    public string Pwd { get; set; }
    public string ServerURL { get; set; }
    public decimal? ProcessTimeout { get; set; }
    public string EnableAmountRound { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentGatewayConfig PaymentGatewayConfig { get; set; }
}