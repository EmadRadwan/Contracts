﻿using System;
using System.Collections.Generic;

namespace Domain;

public class Picklist
{
    public Picklist()
    {
        PicklistBins = new HashSet<PicklistBin>();
        PicklistRoles = new HashSet<PicklistRole>();
        PicklistStatus = new HashSet<PicklistStatu>();
        PicklistStatusHistories = new HashSet<PicklistStatusHistory>();
    }

    public string PicklistId { get; set; }
    public string Description { get; set; }
    public string FacilityId { get; set; }
    public string ShipmentMethodTypeId { get; set; }
    public string StatusId { get; set; }
    public DateTime? PicklistDate { get; set; }
    public DateTime? CreatedDate { get; set; }
    public string CreatedByUserLogin { get; set; }
    public DateTime? LastModifiedDate { get; set; }
    public string LastModifiedByUserLogin { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Facility Facility { get; set; }
    public ShipmentMethodType ShipmentMethodType { get; set; }
    public StatusItem Status { get; set; }
    public ICollection<PicklistBin> PicklistBins { get; set; }
    public ICollection<PicklistRole> PicklistRoles { get; set; }
    public ICollection<PicklistStatu> PicklistStatus { get; set; }
    public ICollection<PicklistStatusHistory> PicklistStatusHistories { get; set; }
}