﻿using System;

namespace Domain;

public class PartyInvitationGroupAssoc
{
    public string PartyInvitationId { get; set; }
    public string PartyIdTo { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyGroup PartyIdTo1 { get; set; }
    public Party PartyIdToNavigation { get; set; }
    public PartyInvitation PartyInvitation { get; set; }
}