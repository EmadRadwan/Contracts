﻿using System;
using System.Collections.Generic;

namespace Domain;

public class TrainingRequest
{
    public TrainingRequest()
    {
        PersonTrainings = new HashSet<PersonTraining>();
    }

    public string TrainingRequestId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<PersonTraining> PersonTrainings { get; set; }
}