﻿using System;

namespace Domain;

public class ShipmentAttribute
{
    public string ShipmentId { get; set; }
    public string AttrName { get; set; }
    public string AttrValue { get; set; }
    public string AttrDescription { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Shipment Shipment { get; set; }
}