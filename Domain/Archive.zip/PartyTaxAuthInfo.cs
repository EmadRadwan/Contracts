﻿using System;

namespace Domain;

public class PartyTaxAuthInfo
{
    public string PartyId { get; set; }
    public string TaxAuthGeoId { get; set; }
    public string TaxAuthPartyId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string PartyTaxId { get; set; }
    public string IsExempt { get; set; }
    public string IsNexus { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public TaxAuthority TaxAuth { get; set; }
}