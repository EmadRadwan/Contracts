﻿using System;

namespace Domain;

public class ProductFeatureDataResource
{
    public string DataResourceId { get; set; }
    public string ProductFeatureId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public DataResource DataResource { get; set; }
    public ProductFeature ProductFeature { get; set; }
}