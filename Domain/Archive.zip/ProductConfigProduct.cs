﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductConfigProduct
{
    public ProductConfigProduct()
    {
        ConfigOptionProductOptions = new HashSet<ConfigOptionProductOption>();
    }

    public string ConfigItemId { get; set; }
    public string ConfigOptionId { get; set; }
    public Guid ProductId { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductConfigOption Config { get; set; }
    public ProductConfigItem ConfigItem { get; set; }
    public Product Product { get; set; }
    public ICollection<ConfigOptionProductOption> ConfigOptionProductOptions { get; set; }
}