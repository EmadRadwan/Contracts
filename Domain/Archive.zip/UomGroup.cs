﻿using System;

namespace Domain;

public class UomGroup
{
    public string UomGroupId { get; set; }
    public string UomId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Uom Uom { get; set; }
}