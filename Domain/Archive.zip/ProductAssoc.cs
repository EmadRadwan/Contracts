﻿using System;

namespace Domain;

public class ProductAssoc
{
    public Guid ProductId { get; set; }
    public Guid ProductIdTo { get; set; }
    public string ProductAssocTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public string Reason { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? ScrapFactor { get; set; }
    public string Instruction { get; set; }
    public string RoutingWorkEffortId { get; set; }
    public string EstimateCalcMethod { get; set; }
    public string RecurrenceInfoId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CustomMethod EstimateCalcMethodNavigation { get; set; }
    public Product Product { get; set; }
    public ProductAssocType ProductAssocType { get; set; }
    public Product ProductIdToNavigation { get; set; }
    public RecurrenceInfo RecurrenceInfo { get; set; }
    public WorkEffort RoutingWorkEffort { get; set; }
}