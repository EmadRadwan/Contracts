﻿using System;

namespace Domain;

public class TemporalExpressionAssoc
{
    public string FromTempExprId { get; set; }
    public string ToTempExprId { get; set; }
    public string ExprAssocType { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public TemporalExpression FromTempExpr { get; set; }
    public TemporalExpression ToTempExpr { get; set; }
}