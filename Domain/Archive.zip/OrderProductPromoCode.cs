﻿using System;

namespace Domain;

public class OrderProductPromoCode
{
    public string OrderId { get; set; }
    public string ProductPromoCodeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public ProductPromoCode ProductPromoCode { get; set; }
}