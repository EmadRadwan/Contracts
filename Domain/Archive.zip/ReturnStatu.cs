﻿using System;

namespace Domain;

public class ReturnStatu
{
    public string ReturnStatusId { get; set; }
    public string StatusId { get; set; }
    public string ReturnId { get; set; }
    public string ReturnItemSeqId { get; set; }
    public string ChangedByUserLoginId { get; set; }
    public DateTime? StatusDatetime { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin ChangeByUserLogin { get; set; }
    public ReturnHeader Return { get; set; }
    public StatusItem Status { get; set; }
}