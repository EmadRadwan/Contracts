﻿using System;

namespace Domain;

public class PortletPortletCategory
{
    public string PortalPortletId { get; set; }
    public string PortletCategoryId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PortalPortlet PortalPortlet { get; set; }
    public PortletCategory PortletCategory { get; set; }
}