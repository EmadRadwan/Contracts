﻿using System;

namespace Domain;

public class WorkRequirementFulfillment
{
    public string RequirementId { get; set; }
    public string WorkEffortId { get; set; }
    public string WorkReqFulfTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Requirement Requirement { get; set; }
    public WorkEffort WorkEffort { get; set; }
    public WorkReqFulfType WorkReqFulfType { get; set; }
}