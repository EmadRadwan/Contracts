﻿using System;

namespace Domain;

public class ProductContent
{
    public Guid ProductId { get; set; }
    public string ContentId { get; set; }
    public string ProductContentTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? PurchaseFromDate { get; set; }
    public DateTime? PurchaseThruDate { get; set; }
    public decimal? UseCountLimit { get; set; }
    public decimal? UseTime { get; set; }
    public string UseTimeUomId { get; set; }
    public string UseRoleTypeId { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public Product Product { get; set; }
    public ProductContentType ProductContentType { get; set; }
    public RoleType UseRoleType { get; set; }
    public Uom UseTimeUom { get; set; }
}