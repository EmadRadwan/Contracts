﻿using System;

namespace Domain;

public class SurveyPage
{
    public string SurveyId { get; set; }
    public string SurveyPageSeqId { get; set; }
    public string PageName { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Survey Survey { get; set; }
}