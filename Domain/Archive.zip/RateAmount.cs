﻿using System;

namespace Domain;

public class RateAmount
{
    public string RateTypeId { get; set; }
    public string RateCurrencyUomId { get; set; }
    public string PeriodTypeId { get; set; }
    public string WorkEffortId { get; set; }
    public string PartyId { get; set; }
    public string EmplPositionTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? RateAmount1 { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public EmplPositionType EmplPositionType { get; set; }
    public Party Party { get; set; }
    public PeriodType PeriodType { get; set; }
    public Uom RateCurrencyUom { get; set; }
    public RateType RateType { get; set; }
    public WorkEffort WorkEffort { get; set; }
}