﻿using System;

namespace Domain;

public class QuoteNote
{
    public string QuoteId { get; set; }
    public string NoteId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public NoteData Note { get; set; }
    public Quote Quote { get; set; }
}