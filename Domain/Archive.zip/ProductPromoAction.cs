﻿using System;

namespace Domain;

public class ProductPromoAction
{
    public string ProductPromoId { get; set; }
    public string ProductPromoRuleId { get; set; }
    public string ProductPromoActionSeqId { get; set; }
    public string ProductPromoActionEnumId { get; set; }
    public string CustomMethodId { get; set; }
    public string OrderAdjustmentTypeId { get; set; }
    public string ServiceName { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? Amount { get; set; }
    public Guid ProductId { get; set; }
    public string PartyId { get; set; }
    public string UseCartQuantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CustomMethod CustomMethod { get; set; }
    public OrderAdjustmentType OrderAdjustmentType { get; set; }
    public ProductPromo ProductPromo { get; set; }
    public Enumeration ProductPromoActionEnum { get; set; }
    public ProductPromoRule ProductPromoNavigation { get; set; }
}