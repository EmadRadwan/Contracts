﻿using System;

namespace Domain;

public class ProductMeter
{
    public Guid ProductId { get; set; }
    public string ProductMeterTypeId { get; set; }
    public string MeterUomId { get; set; }
    public string MeterName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Uom MeterUom { get; set; }
    public Product Product { get; set; }
    public ProductMeterType ProductMeterType { get; set; }
}