﻿using System;

namespace Domain;

public class RoleTypeAttr
{
    public string RoleTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public RoleType RoleType { get; set; }
}