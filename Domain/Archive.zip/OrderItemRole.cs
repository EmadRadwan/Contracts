﻿using System;

namespace Domain;

public class OrderItemRole
{
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public OrderItem OrderI { get; set; }
    public Party Party { get; set; }
    public PartyRole PartyRole { get; set; }
}