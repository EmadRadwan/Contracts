﻿using System;

namespace Domain;

public class PartyContent
{
    public string PartyId { get; set; }
    public string ContentId { get; set; }
    public string PartyContentTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public Party Party { get; set; }
    public PartyContentType PartyContentType { get; set; }
}