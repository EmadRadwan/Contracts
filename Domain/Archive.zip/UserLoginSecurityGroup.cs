﻿using System;

namespace Domain;

public class UserLoginSecurityGroup
{
    public string UserLoginId { get; set; }
    public string GroupId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SecurityGroup Group { get; set; }
    public AppUserLogin UserLogin { get; set; }
}