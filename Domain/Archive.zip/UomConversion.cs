﻿using System;

namespace Domain;

public class UomConversion
{
    public string UomId { get; set; }
    public string UomIdTo { get; set; }
    public double? ConversionFactor { get; set; }
    public string CustomMethodId { get; set; }
    public decimal? DecimalScale { get; set; }
    public string RoundingMode { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CustomMethod CustomMethod { get; set; }
    public Uom Uom { get; set; }
    public Uom UomIdToNavigation { get; set; }
}