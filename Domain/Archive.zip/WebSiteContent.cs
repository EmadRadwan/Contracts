﻿using System;

namespace Domain;

public class WebSiteContent
{
    public string WebSiteId { get; set; }
    public string ContentId { get; set; }
    public string WebSiteContentTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public WebSite WebSite { get; set; }
    public WebSiteContentType WebSiteContentType { get; set; }
}