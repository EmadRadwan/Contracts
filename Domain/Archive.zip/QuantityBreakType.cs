﻿using System;
using System.Collections.Generic;

namespace Domain;

public class QuantityBreakType
{
    public QuantityBreakType()
    {
        QuantityBreaks = new HashSet<QuantityBreak>();
    }

    public string QuantityBreakTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<QuantityBreak> QuantityBreaks { get; set; }
}