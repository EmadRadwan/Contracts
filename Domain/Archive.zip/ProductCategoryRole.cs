﻿using System;

namespace Domain;

public class ProductCategoryRole
{
    public string ProductCategoryId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyRole PartyRole { get; set; }
    public ProductCategory ProductCategory { get; set; }
}