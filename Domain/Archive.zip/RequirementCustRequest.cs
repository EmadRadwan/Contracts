﻿using System;

namespace Domain;

public class RequirementCustRequest
{
    public string CustRequestId { get; set; }
    public string CustRequestItemSeqId { get; set; }
    public string RequirementId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CustRequestItem CustRequestI { get; set; }
    public Requirement Requirement { get; set; }
}