﻿using System;

namespace Domain;

public class SurveyResponseAnswer
{
    public string SurveyResponseId { get; set; }
    public string SurveyQuestionId { get; set; }
    public string SurveyMultiRespColId { get; set; }
    public string SurveyMultiRespId { get; set; }
    public string BooleanResponse { get; set; }
    public decimal? CurrencyResponse { get; set; }
    public double? FloatResponse { get; set; }
    public decimal? NumericResponse { get; set; }
    public string TextResponse { get; set; }
    public string SurveyOptionSeqId { get; set; }
    public string ContentId { get; set; }
    public DateTime? AnsweredDate { get; set; }
    public decimal? AmountBase { get; set; }
    public string AmountBaseUomId { get; set; }
    public double? WeightFactor { get; set; }
    public decimal? Duration { get; set; }
    public string DurationUomId { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public SurveyQuestionOption Survey { get; set; }
    public SurveyQuestion SurveyQuestion { get; set; }
    public SurveyResponse SurveyResponse { get; set; }
}