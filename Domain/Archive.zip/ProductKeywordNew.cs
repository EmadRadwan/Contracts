﻿using System;

namespace Domain;

public class ProductKeywordNew
{
    public Guid ProductId { get; set; }
    public string Keyword { get; set; }
    public string KeywordTypeId { get; set; }
    public decimal? RelevancyWeight { get; set; }
    public string StatusId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Enumeration KeywordType { get; set; }
    public Product Product { get; set; }
    public StatusItem Status { get; set; }
}