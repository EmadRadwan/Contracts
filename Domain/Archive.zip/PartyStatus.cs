using System;

namespace Domain;

public class PartyStatus
{
    public string StatusId { get; set; }
    public string PartyId { get; set; }
    public DateTime StatusDate { get; set; }
    public string? ChangedByUserLoginId { get; set; }

    public DateTime CreatedStamp { get; set; }
    public DateTime LastUpdatedStamp { get; set; }

    public AppUserLogin? AppUserLogin { get; set; }
    public Party? Party { get; set; }
    public StatusItem? Status { get; set; }
}