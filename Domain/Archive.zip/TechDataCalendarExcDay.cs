﻿using System;

namespace Domain;

public class TechDataCalendarExcDay
{
    public string CalendarId { get; set; }
    public DateTime ExceptionDateStartTime { get; set; }
    public decimal? ExceptionCapacity { get; set; }
    public decimal? UsedCapacity { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public TechDataCalendar Calendar { get; set; }
}