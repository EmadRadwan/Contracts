﻿using System;

namespace Domain;

public class TermTypeAttr
{
    public string TermTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public TermType TermType { get; set; }
}