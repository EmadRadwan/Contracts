﻿using System;

namespace Domain;

public class SurveyQuestionAppl
{
    public string SurveyId { get; set; }
    public string SurveyQuestionId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string SurveyPageSeqId { get; set; }
    public string SurveyMultiRespId { get; set; }
    public string SurveyMultiRespColId { get; set; }
    public string RequiredField { get; set; }
    public decimal? SequenceNum { get; set; }
    public string ExternalFieldRef { get; set; }
    public string WithSurveyQuestionId { get; set; }
    public string WithSurveyOptionSeqId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Survey Survey { get; set; }
    public SurveyQuestion SurveyQuestion { get; set; }
    public SurveyQuestionOption WithSurvey { get; set; }
}