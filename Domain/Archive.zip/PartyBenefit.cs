﻿using System;

namespace Domain;

public class PartyBenefit
{
    public string RoleTypeIdFrom { get; set; }
    public string RoleTypeIdTo { get; set; }
    public string PartyIdFrom { get; set; }
    public string PartyIdTo { get; set; }
    public string BenefitTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string PeriodTypeId { get; set; }
    public decimal? Cost { get; set; }
    public double? ActualEmployerPaidPercent { get; set; }
    public decimal? AvailableTime { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public BenefitType BenefitType { get; set; }
    public Party PartyIdFromNavigation { get; set; }
    public Party PartyIdToNavigation { get; set; }
    public PartyRole PartyRole { get; set; }
    public PartyRole PartyRoleNavigation { get; set; }
}