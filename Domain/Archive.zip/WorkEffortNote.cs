﻿using System;

namespace Domain;

public class WorkEffortNote
{
    public string WorkEffortId { get; set; }
    public string NoteId { get; set; }
    public string InternalNote { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public NoteData Note { get; set; }
    public WorkEffort WorkEffort { get; set; }
}