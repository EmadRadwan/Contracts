﻿using System;

namespace Domain;

public class WorkEffortFixedAssetStd
{
    public string WorkEffortId { get; set; }
    public string FixedAssetTypeId { get; set; }
    public double? EstimatedQuantity { get; set; }
    public double? EstimatedDuration { get; set; }
    public decimal? EstimatedCost { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public FixedAssetType FixedAssetType { get; set; }
    public WorkEffort WorkEffort { get; set; }
}