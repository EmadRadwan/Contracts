﻿using System;

namespace Domain;

public class ProductFeatureCatGrpAppl
{
    public string ProductCategoryId { get; set; }
    public string ProductFeatureGroupId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductCategory ProductCategory { get; set; }
    public ProductFeatureGroup ProductFeatureGroup { get; set; }
}