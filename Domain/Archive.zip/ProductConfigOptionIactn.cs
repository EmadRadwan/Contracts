﻿using System;

namespace Domain;

public class ProductConfigOptionIactn
{
    public string ConfigItemId { get; set; }
    public string ConfigOptionId { get; set; }
    public string ConfigItemIdTo { get; set; }
    public string ConfigOptionIdTo { get; set; }
    public decimal SequenceNum { get; set; }
    public string ConfigIactnTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductConfigOption Config { get; set; }
    public ProductConfigItem ConfigItem { get; set; }
    public ProductConfigItem ConfigItemIdToNavigation { get; set; }
    public ProductConfigOption ConfigNavigation { get; set; }
}