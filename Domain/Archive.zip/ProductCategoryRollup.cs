﻿using System;

namespace Domain;

public class ProductCategoryRollup
{
    public string ProductCategoryId { get; set; }
    public string ParentProductCategoryId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductCategory ParentProductCategory { get; set; }
    public ProductCategory ProductCategory { get; set; }
}