﻿using System;

namespace Domain;

public class ProductPromoCond
{
    public string ProductPromoId { get; set; }
    public string ProductPromoRuleId { get; set; }
    public string ProductPromoCondSeqId { get; set; }
    public string CustomMethodId { get; set; }
    public string InputParamEnumId { get; set; }
    public string OperatorEnumId { get; set; }
    public string CondValue { get; set; }
    public string OtherValue { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CustomMethod CustomMethod { get; set; }
    public Enumeration InputParamEnum { get; set; }
    public Enumeration OperatorEnum { get; set; }
    public ProductPromo ProductPromo { get; set; }
    public ProductPromoRule ProductPromoNavigation { get; set; }
}