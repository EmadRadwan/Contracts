﻿using System;

namespace Domain;

public class PicklistRole
{
    public string PicklistId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string CreatedByUserLogin { get; set; }
    public string LastModifiedByUserLogin { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public AppUserLogin CreatedByUserLoginNavigation { get; set; }
    public AppUserLogin LastModifiedByUserLoginNavigation { get; set; }
    public PartyRole PartyRole { get; set; }
    public Picklist Picklist { get; set; }
}