﻿using System;

namespace Domain;

public class ProductStoreFinActSetting
{
    public string ProductStoreId { get; set; }
    public string FinAccountTypeId { get; set; }
    public string RequirePinCode { get; set; }
    public string ValidateGCFinAcct { get; set; }
    public decimal? AccountCodeLength { get; set; }
    public decimal? PinCodeLength { get; set; }
    public decimal? AccountValidDays { get; set; }
    public decimal? AuthValidDays { get; set; }
    public string PurchaseSurveyId { get; set; }
    public string PurchSurveySendTo { get; set; }
    public string PurchSurveyCopyMe { get; set; }
    public string AllowAuthToNegative { get; set; }
    public decimal? MinBalance { get; set; }
    public decimal? ReplenishThreshold { get; set; }
    public string ReplenishMethodEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public FinAccountType FinAccountType { get; set; }
    public ProductStore ProductStore { get; set; }
    public Survey PurchaseSurvey { get; set; }
    public Enumeration ReplenishMethodEnum { get; set; }
}