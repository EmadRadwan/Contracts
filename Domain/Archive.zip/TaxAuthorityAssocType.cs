﻿using System;
using System.Collections.Generic;

namespace Domain;

public class TaxAuthorityAssocType
{
    public TaxAuthorityAssocType()
    {
        TaxAuthorityAssocs = new HashSet<TaxAuthorityAssoc>();
    }

    public string TaxAuthorityAssocTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<TaxAuthorityAssoc> TaxAuthorityAssocs { get; set; }
}