﻿using System;

namespace Domain;

public class PartyInvitationRoleAssoc
{
    public string PartyInvitationId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyInvitation PartyInvitation { get; set; }
    public RoleType RoleType { get; set; }
}