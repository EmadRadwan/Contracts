﻿using System;

namespace Domain;

public class PaymentGatewayOrbital
{
    public string PaymentGatewayConfigId { get; set; }
    public string Username { get; set; }
    public string ConnectionPassword { get; set; }
    public string MerchantId { get; set; }
    public string EngineClass { get; set; }
    public string HostName { get; set; }
    public decimal? Port { get; set; }
    public string HostNameFailover { get; set; }
    public decimal? PortFailover { get; set; }
    public decimal? ConnectionTimeoutSeconds { get; set; }
    public decimal? ReadTimeoutSeconds { get; set; }
    public string AuthorizationURI { get; set; }
    public string SdkVersion { get; set; }
    public string SslSocketFactory { get; set; }
    public string ResponseType { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentGatewayConfig PaymentGatewayConfig { get; set; }
}