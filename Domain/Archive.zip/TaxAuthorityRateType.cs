﻿using System;
using System.Collections.Generic;

namespace Domain;

public class TaxAuthorityRateType
{
    public TaxAuthorityRateType()
    {
        TaxAuthorityRateProducts = new HashSet<TaxAuthorityRateProduct>();
    }

    public string TaxAuthorityRateTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<TaxAuthorityRateProduct> TaxAuthorityRateProducts { get; set; }
}