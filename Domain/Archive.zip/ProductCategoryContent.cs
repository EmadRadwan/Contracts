﻿using System;

namespace Domain;

public class ProductCategoryContent
{
    public string ProductCategoryId { get; set; }
    public string ContentId { get; set; }
    public string ProdCatContentTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? PurchaseFromDate { get; set; }
    public DateTime? PurchaseThruDate { get; set; }
    public decimal? UseCountLimit { get; set; }
    public decimal? UseDaysLimit { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public ProductCategoryContentType ProdCatContentType { get; set; }
    public ProductCategory ProductCategory { get; set; }
}