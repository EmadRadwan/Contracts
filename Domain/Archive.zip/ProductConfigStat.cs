﻿using System;

namespace Domain;

public class ProductConfigStat
{
    public string ConfigId { get; set; }
    public Guid ProductId { get; set; }
    public decimal? NumOfConfs { get; set; }
    public string ConfigTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
}