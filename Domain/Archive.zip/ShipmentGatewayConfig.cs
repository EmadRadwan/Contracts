﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ShipmentGatewayConfig
{
    public ShipmentGatewayConfig()
    {
        ProductStoreShipmentMeths = new HashSet<ProductStoreShipmentMeth>();
    }

    public string ShipmentGatewayConfigId { get; set; }
    public string ShipmentGatewayConfTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ShipmentGatewayConfigType ShipmentGatewayConfType { get; set; }
    public ShipmentGatewayDhl ShipmentGatewayDhl { get; set; }
    public ShipmentGatewayFedex ShipmentGatewayFedex { get; set; }
    public ShipmentGatewayUp ShipmentGatewayUp { get; set; }
    public ShipmentGatewayUsp ShipmentGatewayUsp { get; set; }
    public ICollection<ProductStoreShipmentMeth> ProductStoreShipmentMeths { get; set; }
}