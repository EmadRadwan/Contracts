﻿using System;

namespace Domain;

public class PayrollPreference
{
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public string PayrollPreferenceSeqId { get; set; }
    public string DeductionTypeId { get; set; }
    public string PaymentMethodTypeId { get; set; }
    public string PeriodTypeId { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public double? Percentage { get; set; }
    public decimal? FlatAmount { get; set; }
    public string RoutingNumber { get; set; }
    public string AccountNumber { get; set; }
    public string BankName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public PartyRole PartyRole { get; set; }
}