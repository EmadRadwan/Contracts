﻿using System;

namespace Domain;

public class TrackingCodeVisit
{
    public string TrackingCodeId { get; set; }
    public string VisitId { get; set; }
    public DateTime FromDate { get; set; }
    public string SourceEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Enumeration SourceEnum { get; set; }
    public TrackingCode TrackingCode { get; set; }
}