﻿using System;

namespace Domain;

public class SegmentGroupClassification
{
    public string SegmentGroupId { get; set; }
    public string PartyClassificationGroupId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyClassificationGroup PartyClassificationGroup { get; set; }
    public SegmentGroup SegmentGroup { get; set; }
}