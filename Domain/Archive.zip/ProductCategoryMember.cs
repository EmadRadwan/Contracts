﻿using System;

namespace Domain;

public class ProductCategoryMember
{
    public string ProductCategoryId { get; set; }
    public Guid ProductId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string? Comments { get; set; }
    public decimal? SequenceNum { get; set; }
    public decimal? Quantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product? Product { get; set; }
    public ProductCategory? ProductCategory { get; set; }
}