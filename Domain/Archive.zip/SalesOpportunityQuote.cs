﻿using System;

namespace Domain;

public class SalesOpportunityQuote
{
    public string SalesOpportunityId { get; set; }
    public string QuoteId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Quote Quote { get; set; }
    public SalesOpportunity SalesOpportunity { get; set; }
}