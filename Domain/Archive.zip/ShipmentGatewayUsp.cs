﻿using System;

namespace Domain;

public class ShipmentGatewayUsp
{
    public string ShipmentGatewayConfigId { get; set; }
    public string ConnectUrl { get; set; }
    public string ConnectUrlLabels { get; set; }
    public decimal? ConnectTimeout { get; set; }
    public string AccessUserId { get; set; }
    public string AccessPassword { get; set; }
    public decimal? MaxEstimateWeight { get; set; }
    public string Test { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ShipmentGatewayConfig ShipmentGatewayConfig { get; set; }
}