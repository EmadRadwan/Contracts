﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductPricePurpose
{
    public ProductPricePurpose()
    {
        OrderPaymentPreferences = new HashSet<OrderPaymentPreference>();
        ProductPaymentMethodTypes = new HashSet<ProductPaymentMethodType>();
        ProductPrices = new HashSet<ProductPrice>();
    }

    public string ProductPricePurposeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<OrderPaymentPreference> OrderPaymentPreferences { get; set; }
    public ICollection<ProductPaymentMethodType> ProductPaymentMethodTypes { get; set; }
    public ICollection<ProductPrice> ProductPrices { get; set; }
}