﻿using System;

namespace Domain;

public class QuoteRole
{
    public string QuoteId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public PartyRole PartyRole { get; set; }
    public Quote Quote { get; set; }
}