﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PerfReview
{
    public PerfReview()
    {
        PerfReviewItems = new HashSet<PerfReviewItem>();
    }

    public string EmployeePartyId { get; set; }
    public string EmployeeRoleTypeId { get; set; }
    public string PerfReviewId { get; set; }
    public string ManagerPartyId { get; set; }
    public string ManagerRoleTypeId { get; set; }
    public string PaymentId { get; set; }
    public string EmplPositionId { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyRole Employee { get; set; }
    public Party EmployeeParty { get; set; }
    public Party ManagerParty { get; set; }
    public Payment Payment { get; set; }
    public ICollection<PerfReviewItem> PerfReviewItems { get; set; }
}