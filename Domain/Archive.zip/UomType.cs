﻿using System;
using System.Collections.Generic;

namespace Domain;

public class UomType
{
    public UomType()
    {
        InverseParentType = new HashSet<UomType>();
        Products = new HashSet<Product>();
        Uoms = new HashSet<Uom>();
    }

    public string UomTypeId { get; set; }
    public string? ParentTypeId { get; set; }
    public string? HasTable { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public virtual UomType ParentType { get; set; }
    public ICollection<UomType> InverseParentType { get; set; }
    public ICollection<Product> Products { get; set; }
    public ICollection<Uom> Uoms { get; set; }
}