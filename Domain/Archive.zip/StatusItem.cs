﻿using System;
using System.Collections.Generic;

namespace Domain;

public class StatusItem
{
    public StatusItem()
    {
        AcctgTrans = new HashSet<AcctgTran>();
        AcctgTransEntries = new HashSet<AcctgTransEntry>();
        AllocationPlanHeaders = new HashSet<AllocationPlanHeader>();
        AllocationPlanItems = new HashSet<AllocationPlanItem>();
        BudgetStatus = new HashSet<BudgetStatu>();
        CommunicationEventRoles = new HashSet<CommunicationEventRole>();
        CommunicationEvents = new HashSet<CommunicationEvent>();
        ContactListCommStatus = new HashSet<ContactListCommStatus>();
        ContactListParties = new HashSet<ContactListParty>();
        ContentApprovals = new HashSet<ContentApproval>();
        ContentPurposeOperations = new HashSet<ContentPurposeOperation>();
        Contents = new HashSet<Content>();
        CustRequestItems = new HashSet<CustRequestItem>();
        CustRequestStatus = new HashSet<CustRequestStatu>();
        CustRequests = new HashSet<CustRequest>();
        DataResources = new HashSet<DataResource>();
        EmplLeaves = new HashSet<EmplLeave>();
        EmplPositions = new HashSet<EmplPosition>();
        FinAccountStatus = new HashSet<FinAccountStatu>();
        FinAccountTrans = new HashSet<FinAccountTran>();
        FixedAssetMaints = new HashSet<FixedAssetMaint>();
        GlReconciliations = new HashSet<GlReconciliation>();
        InventoryItemStatus = new HashSet<InventoryItemStatu>();
        InventoryItems = new HashSet<InventoryItem>();
        InventoryTransfers = new HashSet<InventoryTransfer>();
        InvoiceStatus = new HashSet<InvoiceStatu>();
        Invoices = new HashSet<Invoice>();
        JobSandboxes = new HashSet<JobSandbox>();
        MarketingCampaigns = new HashSet<MarketingCampaign>();
        OrderDeliverySchedules = new HashSet<OrderDeliverySchedule>();
        OrderHeaderStatus = new HashSet<OrderHeader>();
        OrderHeaderSyncStatus = new HashSet<OrderHeader>();
        OrderItemStatus = new HashSet<OrderItem>();
        OrderItemSyncStatus = new HashSet<OrderItem>();
        OrderPaymentPreferences = new HashSet<OrderPaymentPreference>();
        OrderStatus = new HashSet<OrderStatu>();
        Parties = new HashSet<Party>();
        PartyFixedAssetAssignments = new HashSet<PartyFixedAssetAssignment>();
        PartyInvitations = new HashSet<PartyInvitation>();
        PartyQualStatus = new HashSet<PartyQual>();
        PartyQualVerifStatus = new HashSet<PartyQual>();
        PartyRelationships = new HashSet<PartyRelationship>();
        PartyStatus = new HashSet<PartyStatus>();
        Payments = new HashSet<Payment>();
        PicklistItems = new HashSet<PicklistItem>();
        PicklistStatuStatus = new HashSet<PicklistStatu>();
        PicklistStatuStatusIdToNavigations = new HashSet<PicklistStatu>();
        PicklistStatusHistoryStatus = new HashSet<PicklistStatusHistory>();
        PicklistStatusHistoryStatusIdToNavigations = new HashSet<PicklistStatusHistory>();
        Picklists = new HashSet<Picklist>();
        PosTerminalLogs = new HashSet<PosTerminalLog>();
        ProductGroupOrders = new HashSet<ProductGroupOrder>();
        ProductKeywordNews = new HashSet<ProductKeywordNew>();
        ProductReviews = new HashSet<ProductReview>();
        ProductStoreDigitalItemApprovedStatusNavigations = new HashSet<ProductStore>();
        ProductStoreHeaderApprovedStatusNavigations = new HashSet<ProductStore>();
        ProductStoreHeaderCancelStatusNavigations = new HashSet<ProductStore>();
        ProductStoreHeaderDeclinedStatusNavigations = new HashSet<ProductStore>();
        ProductStoreItemApprovedStatusNavigations = new HashSet<ProductStore>();
        ProductStoreItemCancelStatusNavigations = new HashSet<ProductStore>();
        ProductStoreItemDeclinedStatusNavigations = new HashSet<ProductStore>();
        Quotes = new HashSet<Quote>();
        RequirementStatus = new HashSet<RequirementStatu>();
        Requirements = new HashSet<Requirement>();
        ReturnHeaders = new HashSet<ReturnHeader>();
        ReturnItemExpectedItemStatusNavigations = new HashSet<ReturnItem>();
        ReturnItemStatus = new HashSet<ReturnItem>();
        ReturnStatus = new HashSet<ReturnStatu>();
        ShipmentRouteSegments = new HashSet<ShipmentRouteSegment>();
        ShipmentStatus = new HashSet<ShipmentStatu>();
        Shipments = new HashSet<Shipment>();
        StatusValidChangeStatus = new HashSet<StatusValidChange>();
        StatusValidChangeStatusIdToNavigations = new HashSet<StatusValidChange>();
        SurveyResponses = new HashSet<SurveyResponse>();
        Timesheets = new HashSet<Timesheet>();
        WorkEffortFixedAssetAssignAvailabilityStatus = new HashSet<WorkEffortFixedAssetAssign>();
        WorkEffortFixedAssetAssignStatus = new HashSet<WorkEffortFixedAssetAssign>();
        WorkEffortGoodStandards = new HashSet<WorkEffortGoodStandard>();
        WorkEffortInventoryAssigns = new HashSet<WorkEffortInventoryAssign>();
        WorkEffortPartyAssignmentAvailabilityStatus = new HashSet<WorkEffortPartyAssignment>();
        WorkEffortPartyAssignmentStatus = new HashSet<WorkEffortPartyAssignment>();
        WorkEffortReviews = new HashSet<WorkEffortReview>();
        WorkEffortStatus = new HashSet<WorkEffortStatu>();
        WorkEfforts = new HashSet<WorkEffort>();
    }

    public string StatusId { get; set; }
    public string StatusTypeId { get; set; }
    public string StatusCode { get; set; }
    public string SequenceId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public StatusType StatusType { get; set; }
    public ICollection<AcctgTran> AcctgTrans { get; set; }
    public ICollection<AcctgTransEntry> AcctgTransEntries { get; set; }
    public ICollection<AllocationPlanHeader> AllocationPlanHeaders { get; set; }
    public ICollection<AllocationPlanItem> AllocationPlanItems { get; set; }
    public ICollection<BudgetStatu> BudgetStatus { get; set; }
    public ICollection<CommunicationEventRole> CommunicationEventRoles { get; set; }
    public ICollection<CommunicationEvent> CommunicationEvents { get; set; }
    public ICollection<ContactListCommStatus> ContactListCommStatus { get; set; }
    public ICollection<ContactListParty> ContactListParties { get; set; }
    public ICollection<ContentApproval> ContentApprovals { get; set; }
    public ICollection<ContentPurposeOperation> ContentPurposeOperations { get; set; }
    public ICollection<Content> Contents { get; set; }
    public ICollection<CustRequestItem> CustRequestItems { get; set; }
    public ICollection<CustRequestStatu> CustRequestStatus { get; set; }
    public ICollection<CustRequest> CustRequests { get; set; }
    public ICollection<DataResource> DataResources { get; set; }
    public ICollection<EmplLeave> EmplLeaves { get; set; }
    public ICollection<EmplPosition> EmplPositions { get; set; }
    public ICollection<FinAccountStatu> FinAccountStatus { get; set; }
    public ICollection<FinAccountTran> FinAccountTrans { get; set; }
    public ICollection<FixedAssetMaint> FixedAssetMaints { get; set; }
    public ICollection<GlReconciliation> GlReconciliations { get; set; }
    public ICollection<InventoryItemStatu> InventoryItemStatus { get; set; }
    public ICollection<InventoryItem> InventoryItems { get; set; }
    public ICollection<InventoryTransfer> InventoryTransfers { get; set; }
    public ICollection<InvoiceStatu> InvoiceStatus { get; set; }
    public ICollection<Invoice> Invoices { get; set; }
    public ICollection<JobSandbox> JobSandboxes { get; set; }
    public ICollection<MarketingCampaign> MarketingCampaigns { get; set; }
    public ICollection<OrderDeliverySchedule> OrderDeliverySchedules { get; set; }
    public ICollection<OrderHeader> OrderHeaderStatus { get; set; }
    public ICollection<OrderHeader> OrderHeaderSyncStatus { get; set; }
    public ICollection<OrderItem> OrderItemStatus { get; set; }
    public ICollection<OrderItem> OrderItemSyncStatus { get; set; }
    public ICollection<OrderPaymentPreference> OrderPaymentPreferences { get; set; }
    public ICollection<OrderStatu> OrderStatus { get; set; }
    public ICollection<Party> Parties { get; set; }
    public ICollection<PartyFixedAssetAssignment> PartyFixedAssetAssignments { get; set; }
    public ICollection<PartyInvitation> PartyInvitations { get; set; }
    public ICollection<PartyQual> PartyQualStatus { get; set; }
    public ICollection<PartyQual> PartyQualVerifStatus { get; set; }
    public ICollection<PartyRelationship> PartyRelationships { get; set; }
    public ICollection<PartyStatus> PartyStatus { get; set; }
    public ICollection<Payment> Payments { get; set; }
    public ICollection<PicklistItem> PicklistItems { get; set; }
    public ICollection<PicklistStatu> PicklistStatuStatus { get; set; }
    public ICollection<PicklistStatu> PicklistStatuStatusIdToNavigations { get; set; }
    public ICollection<PicklistStatusHistory> PicklistStatusHistoryStatus { get; set; }
    public ICollection<PicklistStatusHistory> PicklistStatusHistoryStatusIdToNavigations { get; set; }
    public ICollection<Picklist> Picklists { get; set; }
    public ICollection<PosTerminalLog> PosTerminalLogs { get; set; }
    public ICollection<ProductGroupOrder> ProductGroupOrders { get; set; }
    public ICollection<ProductKeywordNew> ProductKeywordNews { get; set; }
    public ICollection<ProductReview> ProductReviews { get; set; }
    public ICollection<ProductStore> ProductStoreDigitalItemApprovedStatusNavigations { get; set; }
    public ICollection<ProductStore> ProductStoreHeaderApprovedStatusNavigations { get; set; }
    public ICollection<ProductStore> ProductStoreHeaderCancelStatusNavigations { get; set; }
    public ICollection<ProductStore> ProductStoreHeaderDeclinedStatusNavigations { get; set; }
    public ICollection<ProductStore> ProductStoreItemApprovedStatusNavigations { get; set; }
    public ICollection<ProductStore> ProductStoreItemCancelStatusNavigations { get; set; }
    public ICollection<ProductStore> ProductStoreItemDeclinedStatusNavigations { get; set; }
    public ICollection<Quote> Quotes { get; set; }
    public ICollection<RequirementStatu> RequirementStatus { get; set; }
    public ICollection<Requirement> Requirements { get; set; }
    public ICollection<ReturnHeader> ReturnHeaders { get; set; }
    public ICollection<ReturnItem> ReturnItemExpectedItemStatusNavigations { get; set; }
    public ICollection<ReturnItem> ReturnItemStatus { get; set; }
    public ICollection<ReturnStatu> ReturnStatus { get; set; }
    public ICollection<ShipmentRouteSegment> ShipmentRouteSegments { get; set; }
    public ICollection<ShipmentStatu> ShipmentStatus { get; set; }
    public ICollection<Shipment> Shipments { get; set; }
    public ICollection<StatusValidChange> StatusValidChangeStatus { get; set; }
    public ICollection<StatusValidChange> StatusValidChangeStatusIdToNavigations { get; set; }
    public ICollection<SurveyResponse> SurveyResponses { get; set; }
    public ICollection<Timesheet> Timesheets { get; set; }
    public ICollection<WorkEffortFixedAssetAssign> WorkEffortFixedAssetAssignAvailabilityStatus { get; set; }
    public ICollection<WorkEffortFixedAssetAssign> WorkEffortFixedAssetAssignStatus { get; set; }
    public ICollection<WorkEffortGoodStandard> WorkEffortGoodStandards { get; set; }
    public ICollection<WorkEffortInventoryAssign> WorkEffortInventoryAssigns { get; set; }
    public ICollection<WorkEffortPartyAssignment> WorkEffortPartyAssignmentAvailabilityStatus { get; set; }
    public ICollection<WorkEffortPartyAssignment> WorkEffortPartyAssignmentStatus { get; set; }
    public ICollection<WorkEffortReview> WorkEffortReviews { get; set; }
    public ICollection<WorkEffortStatu> WorkEffortStatus { get; set; }
    public ICollection<WorkEffort> WorkEfforts { get; set; }
}