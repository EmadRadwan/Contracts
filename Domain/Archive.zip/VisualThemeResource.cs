﻿using System;

namespace Domain;

public class VisualThemeResource
{
    public string VisualThemeId { get; set; }
    public string ResourceTypeEnumId { get; set; }
    public string SequenceId { get; set; }
    public string ResourceValue { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Enumeration ResourceTypeEnum { get; set; }
    public VisualTheme VisualTheme { get; set; }
}