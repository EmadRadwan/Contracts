﻿using System;
using System.Collections.Generic;

namespace Domain;

public class StatusValidChange
{
    public StatusValidChange()
    {
        PicklistStatusHistories = new HashSet<PicklistStatusHistory>();
    }

    public string StatusId { get; set; }
    public string StatusIdTo { get; set; }
    public string? ConditionExpression { get; set; }
    public string TransitionName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public StatusItem Status { get; set; }
    public StatusItem StatusIdToNavigation { get; set; }
    public ICollection<PicklistStatusHistory> PicklistStatusHistories { get; set; }
}