﻿using System;

namespace Domain;

public class ReturnItemBilling
{
    public string ReturnId { get; set; }
    public string ReturnItemSeqId { get; set; }
    public string InvoiceId { get; set; }
    public string InvoiceItemSeqId { get; set; }
    public string ShipmentReceiptId { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? Amount { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InvoiceItem InvoiceI { get; set; }
    public ReturnHeader Return { get; set; }
    public ReturnItem ReturnI { get; set; }
    public ShipmentReceipt ShipmentReceipt { get; set; }
}