﻿using System;

namespace Domain;

public class ProductManufacturingRule
{
    public string RuleId { get; set; }
    public Guid ProductId { get; set; }
    public Guid ProductIdFor { get; set; }
    public Guid ProductIdIn { get; set; }
    public string RuleSeqId { get; set; }
    public DateTime? FromDate { get; set; }
    public Guid ProductIdInSubst { get; set; }
    public string ProductFeature { get; set; }
    public string RuleOperator { get; set; }
    public double? Quantity { get; set; }
    public string Description { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
    public ProductFeature ProductFeatureNavigation { get; set; }
    public Product ProductIdForNavigation { get; set; }
    public Product ProductIdInNavigation { get; set; }
    public Product ProductIdInSubstNavigation { get; set; }
}