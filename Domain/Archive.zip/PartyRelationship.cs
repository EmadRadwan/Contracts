﻿using System;

namespace Domain;

public class PartyRelationship
{
    public string PartyIdFrom { get; set; }
    public string PartyIdTo { get; set; }
    public string RoleTypeIdFrom { get; set; }
    public string RoleTypeIdTo { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string StatusId { get; set; }
    public string RelationshipName { get; set; }
    public string SecurityGroupId { get; set; }
    public string PriorityTypeId { get; set; }
    public string PartyRelationshipTypeId { get; set; }
    public string PermissionsEnumId { get; set; }
    public string PositionTitle { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyRelationshipType PartyRelationshipType { get; set; }
    public PartyRole PartyRole { get; set; }
    public PartyRole PartyRoleNavigation { get; set; }
    public PriorityType PriorityType { get; set; }
    public SecurityGroup SecurityGroup { get; set; }
    public StatusItem Status { get; set; }
}