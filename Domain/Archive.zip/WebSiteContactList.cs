﻿using System;

namespace Domain;

public class WebSiteContactList
{
    public string WebSiteId { get; set; }
    public string ContactListId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactList ContactList { get; set; }
    public WebSite WebSite { get; set; }
}