﻿using System;
using System.Collections.Generic;

namespace Domain;

public class RecurrenceRule
{
    public RecurrenceRule()
    {
        RecurrenceInfoExceptionRules = new HashSet<RecurrenceInfo>();
        RecurrenceInfoRecurrenceRules = new HashSet<RecurrenceInfo>();
    }

    public string RecurrenceRuleId { get; set; }
    public string Frequency { get; set; }
    public DateTime? UntilDateTime { get; set; }
    public decimal? CountNumber { get; set; }
    public decimal? IntervalNumber { get; set; }
    public string BySecondList { get; set; }
    public string ByMinuteList { get; set; }
    public string ByHourList { get; set; }
    public string ByDayList { get; set; }
    public string ByMonthDayList { get; set; }
    public string ByYearDayList { get; set; }
    public string ByWeekNoList { get; set; }
    public string ByMonthList { get; set; }
    public string BySetPosList { get; set; }
    public string WeekStart { get; set; }
    public string XName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<RecurrenceInfo> RecurrenceInfoExceptionRules { get; set; }
    public ICollection<RecurrenceInfo> RecurrenceInfoRecurrenceRules { get; set; }
}