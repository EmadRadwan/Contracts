﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProtocolType
{
    public ProtocolType()
    {
        UserAgents = new HashSet<UserAgent>();
    }

    public string ProtocolTypeId { get; set; }
    public string ProtocolName { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<UserAgent> UserAgents { get; set; }
}