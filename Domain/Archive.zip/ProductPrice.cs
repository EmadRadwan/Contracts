﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain;

public class ProductPrice
{
    public Guid ProductId { get; set; }
    public string ProductPriceTypeId { get; set; }
    public string? ProductPricePurposeId { get; set; }
    public string CurrencyUomId { get; set; }
    public string? ProductStoreGroupId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? Price { get; set; }
    public string? TermUomId { get; set; }
    public string? CustomPriceCalcService { get; set; }
    public decimal? PriceWithoutTax { get; set; }
    public decimal? PriceWithTax { get; set; }
    public decimal? TaxAmount { get; set; }
    public decimal? TaxPercentage { get; set; }
    public string? TaxAuthPartyId { get; set; }
    public string? TaxAuthGeoId { get; set; }
    public string? TaxInPrice { get; set; }
    public DateTime? CreatedDate { get; set; }
    public string? CreatedByUserLogin { get; set; }
    public DateTime? LastModifiedDate { get; set; }
    public string? LastModifiedByUserLogin { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
    
    [Timestamp]
    public byte[] RowVersion { get; set; }

    public AppUserLogin? CreatedByUserLoginNavigation { get; set; }
    public Uom? CurrencyUom { get; set; }
    public CustomMethod? CustomPriceCalcServiceNavigation { get; set; }
    public AppUserLogin? LastModifiedByUserLoginNavigation { get; set; }
    public Product? Product { get; set; }
    public ProductPricePurpose? ProductPricePurpose { get; set; }
    public ProductPriceType? ProductPriceType { get; set; }
    public ProductStoreGroup? ProductStoreGroup { get; set; }
    public Geo? TaxAuthGeo { get; set; }
    public Party? TaxAuthParty { get; set; }
    public Uom? TermUom { get; set; }
}