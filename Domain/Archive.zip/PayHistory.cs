﻿using System;

namespace Domain;

public class PayHistory
{
    public string RoleTypeIdFrom { get; set; }
    public string RoleTypeIdTo { get; set; }
    public string PartyIdFrom { get; set; }
    public string PartyIdTo { get; set; }
    public DateTime EmplFromDate { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string SalaryStepSeqId { get; set; }
    public string PayGradeId { get; set; }
    public string PeriodTypeId { get; set; }
    public decimal? Amount { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Employment Employment { get; set; }
    public PayGrade PayGrade { get; set; }
    public PeriodType PeriodType { get; set; }
}