﻿using System;

namespace Domain;

public class WorkEffortInventoryAssign
{
    public string WorkEffortId { get; set; }
    public string InventoryItemId { get; set; }
    public string StatusId { get; set; }
    public double? Quantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InventoryItem InventoryItem { get; set; }
    public StatusItem Status { get; set; }
    public WorkEffort WorkEffort { get; set; }
}