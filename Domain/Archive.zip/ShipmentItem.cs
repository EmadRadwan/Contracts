﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ShipmentItem
{
    public ShipmentItem()
    {
        ItemIssuances = new HashSet<ItemIssuance>();
        ReturnItemShipments = new HashSet<ReturnItemShipment>();
        ShipmentItemBillings = new HashSet<ShipmentItemBilling>();
        ShipmentItemFeatures = new HashSet<ShipmentItemFeature>();
        ShipmentPackageContents = new HashSet<ShipmentPackageContent>();
        ShippingDocuments = new HashSet<ShippingDocument>();
    }

    public string ShipmentId { get; set; }
    public string ShipmentItemSeqId { get; set; }
    public Guid ProductId { get; set; }
    public decimal? Quantity { get; set; }
    public string ShipmentContentDescription { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
    public Shipment Shipment { get; set; }
    public ICollection<ItemIssuance> ItemIssuances { get; set; }
    public ICollection<ReturnItemShipment> ReturnItemShipments { get; set; }
    public ICollection<ShipmentItemBilling> ShipmentItemBillings { get; set; }
    public ICollection<ShipmentItemFeature> ShipmentItemFeatures { get; set; }
    public ICollection<ShipmentPackageContent> ShipmentPackageContents { get; set; }
    public ICollection<ShippingDocument> ShippingDocuments { get; set; }
}