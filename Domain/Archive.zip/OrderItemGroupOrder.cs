﻿using System;

namespace Domain;

public class OrderItemGroupOrder
{
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string GroupOrderId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductGroupOrder GroupOrder { get; set; }
    public OrderItem OrderI { get; set; }
}