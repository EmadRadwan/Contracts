﻿using System;

namespace Domain;

public class ProductFeatureIactn
{
    public string ProductFeatureId { get; set; }
    public string ProductFeatureIdTo { get; set; }
    public string ProductFeatureIactnTypeId { get; set; }
    public Guid ProductId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductFeature ProductFeature { get; set; }
    public ProductFeatureIactnType ProductFeatureIactnType { get; set; }
    public ProductFeature ProductFeatureIdToNavigation { get; set; }
}