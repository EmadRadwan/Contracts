﻿using System;

namespace Domain;

public class PartyProfileDefault
{
    public string PartyId { get; set; }
    public string ProductStoreId { get; set; }
    public string DefaultShipAddr { get; set; }
    public string DefaultBillAddr { get; set; }
    public string DefaultPayMeth { get; set; }
    public string DefaultShipMeth { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public ProductStore ProductStore { get; set; }
}