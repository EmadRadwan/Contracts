﻿using System;

namespace Domain;

public class ProdConfItemContent
{
    public string ConfigItemId { get; set; }
    public string ContentId { get; set; }
    public string ConfItemContentTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProdConfItemContentType ConfItemContentType { get; set; }
    public ProductConfigItem ConfigItem { get; set; }
    public Content Content { get; set; }
}