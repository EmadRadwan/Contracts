﻿using System;

namespace Domain;

public class QuoteCoefficient
{
    public string QuoteId { get; set; }
    public string CoeffName { get; set; }
    public decimal? CoeffValue { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Quote Quote { get; set; }
}