﻿using System;

namespace Domain;

public class OrderItemShipGrpInvRe
{
    public string OrderId { get; set; }
    public string ShipGroupSeqId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string InventoryItemId { get; set; }
    public string ReserveOrderEnumId { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? QuantityNotAvailable { get; set; }
    public DateTime? ReservedDatetime { get; set; }
    public DateTime? CreatedDatetime { get; set; }
    public DateTime? PromisedDatetime { get; set; }
    public DateTime? CurrentPromisedDate { get; set; }
    public string Priority { get; set; }
    public decimal? SequenceId { get; set; }
    public DateTime? PickStartDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InventoryItem InventoryItem { get; set; }
    public OrderItem OrderI { get; set; }
}