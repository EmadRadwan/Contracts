﻿using System;

namespace Domain;

public class VarianceReasonGlAccount
{
    public string VarianceReasonId { get; set; }
    public string OrganizationPartyId { get; set; }
    public string GlAccountId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public GlAccount GlAccount { get; set; }
    public Party OrganizationParty { get; set; }
    public VarianceReason VarianceReason { get; set; }
}