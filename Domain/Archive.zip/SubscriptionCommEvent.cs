﻿using System;

namespace Domain;

public class SubscriptionCommEvent
{
    public string SubscriptionId { get; set; }
    public string CommunicationEventId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CommunicationEvent CommunicationEvent { get; set; }
    public Subscription Subscription { get; set; }
}