﻿using System;

namespace Domain;

public class SurveyMultiRespColumn
{
    public string SurveyId { get; set; }
    public string SurveyMultiRespId { get; set; }
    public string SurveyMultiRespColId { get; set; }
    public string ColumnTitle { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SurveyMultiResp Survey { get; set; }
}