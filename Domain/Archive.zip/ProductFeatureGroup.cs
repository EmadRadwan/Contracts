﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductFeatureGroup
{
    public ProductFeatureGroup()
    {
        ProductFeatureCatGrpAppls = new HashSet<ProductFeatureCatGrpAppl>();
        ProductFeatureGroupAppls = new HashSet<ProductFeatureGroupAppl>();
    }

    public string ProductFeatureGroupId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<ProductFeatureCatGrpAppl> ProductFeatureCatGrpAppls { get; set; }
    public ICollection<ProductFeatureGroupAppl> ProductFeatureGroupAppls { get; set; }
}