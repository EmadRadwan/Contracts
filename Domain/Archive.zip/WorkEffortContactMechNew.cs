﻿using System;

namespace Domain;

public class WorkEffortContactMechNew
{
    public string WorkEffortId { get; set; }
    public string ContactMechId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMech ContactMech { get; set; }
    public WorkEffort WorkEffort { get; set; }
}