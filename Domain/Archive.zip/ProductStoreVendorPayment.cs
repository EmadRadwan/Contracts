﻿using System;

namespace Domain;

public class ProductStoreVendorPayment
{
    public string ProductStoreId { get; set; }
    public string VendorPartyId { get; set; }
    public string PaymentMethodTypeId { get; set; }
    public string CreditCardEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Enumeration CreditCardEnum { get; set; }
    public PaymentMethodType PaymentMethodType { get; set; }
    public ProductStore ProductStore { get; set; }
    public Party VendorParty { get; set; }
}