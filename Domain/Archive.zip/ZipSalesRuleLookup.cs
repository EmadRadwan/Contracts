﻿using System;

namespace Domain;

public class ZipSalesRuleLookup
{
    public string StateCode { get; set; }
    public string City { get; set; }
    public string County { get; set; }
    public DateTime FromDate { get; set; }
    public string IdCode { get; set; }
    public string Taxable { get; set; }
    public string ShipCond { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
}