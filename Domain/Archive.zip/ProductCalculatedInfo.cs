﻿using System;

namespace Domain;

public class ProductCalculatedInfo
{
    public Guid ProductId { get; set; }
    public decimal? TotalQuantityOrdered { get; set; }
    public decimal? TotalTimesViewed { get; set; }
    public decimal? AverageCustomerRating { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
}