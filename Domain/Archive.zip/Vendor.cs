﻿using System;

namespace Domain;

public class Vendor
{
    public string PartyId { get; set; }
    public string ManifestCompanyName { get; set; }
    public string ManifestCompanyTitle { get; set; }
    public string ManifestLogoUrl { get; set; }
    public string ManifestPolicies { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
}