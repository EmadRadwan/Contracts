﻿using System;

namespace Domain;

public class ShipmentPackageContent
{
    public string ShipmentId { get; set; }
    public string ShipmentPackageSeqId { get; set; }
    public string ShipmentItemSeqId { get; set; }
    public decimal? Quantity { get; set; }
    public Guid SubProductId { get; set; }
    public decimal? SubProductQuantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ShipmentPackage Shipment { get; set; }
    public ShipmentItem ShipmentI { get; set; }
    public Product SubProduct { get; set; }
}