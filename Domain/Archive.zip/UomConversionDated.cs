﻿using System;

namespace Domain;

public class UomConversionDated
{
    public string UomId { get; set; }
    public string UomIdTo { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public double? ConversionFactor { get; set; }
    public string CustomMethodId { get; set; }
    public decimal? DecimalScale { get; set; }
    public string RoundingMode { get; set; }
    public string PurposeEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CustomMethod CustomMethod { get; set; }
    public Enumeration PurposeEnum { get; set; }
    public Uom Uom { get; set; }
    public Uom UomIdToNavigation { get; set; }
}