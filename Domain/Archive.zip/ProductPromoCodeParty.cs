﻿using System;

namespace Domain;

public class ProductPromoCodeParty
{
    public string ProductPromoCodeId { get; set; }
    public string PartyId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public ProductPromoCode ProductPromoCode { get; set; }
}