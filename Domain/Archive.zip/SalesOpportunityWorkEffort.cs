﻿using System;

namespace Domain;

public class SalesOpportunityWorkEffort
{
    public string SalesOpportunityId { get; set; }
    public string WorkEffortId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SalesOpportunity SalesOpportunity { get; set; }
    public WorkEffort WorkEffort { get; set; }
}