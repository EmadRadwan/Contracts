﻿using System;

namespace Domain;

public class SecurityPermission
{
    public string PermissionId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
}