﻿using System;

namespace Domain;

public class WorkEffortAttribute
{
    public string WorkEffortId { get; set; }
    public string AttrName { get; set; }
    public string AttrValue { get; set; }
    public string AttrDescription { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffort WorkEffort { get; set; }
}