﻿using System;
using System.Collections.Generic;

namespace Domain;

public class SurveyQuestionType
{
    public SurveyQuestionType()
    {
        SurveyQuestions = new HashSet<SurveyQuestion>();
    }

    public string SurveyQuestionTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<SurveyQuestion> SurveyQuestions { get; set; }
}