﻿using System;
using System.Collections.Generic;

namespace Domain;

public class RuntimeData
{
    public RuntimeData()
    {
        ApplicationSandboxes = new HashSet<ApplicationSandbox>();
        JobSandboxes = new HashSet<JobSandbox>();
        WorkEfforts = new HashSet<WorkEffort>();
    }

    public string RuntimeDataId { get; set; }
    public string RuntimeInfo { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<ApplicationSandbox> ApplicationSandboxes { get; set; }
    public ICollection<JobSandbox> JobSandboxes { get; set; }
    public ICollection<WorkEffort> WorkEfforts { get; set; }
}