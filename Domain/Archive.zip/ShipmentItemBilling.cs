﻿using System;

namespace Domain;

public class ShipmentItemBilling
{
    public string ShipmentId { get; set; }
    public string ShipmentItemSeqId { get; set; }
    public string InvoiceId { get; set; }
    public string InvoiceItemSeqId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InvoiceItem InvoiceI { get; set; }
    public ShipmentItem ShipmentI { get; set; }
}