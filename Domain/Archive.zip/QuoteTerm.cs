﻿using System;
using System.Collections.Generic;

namespace Domain;

public class QuoteTerm
{
    public QuoteTerm()
    {
        QuoteTermAttributes = new HashSet<QuoteTermAttribute>();
    }

    public string TermTypeId { get; set; }
    public string QuoteId { get; set; }
    public string? QuoteItemSeqId { get; set; }
    public decimal? TermValue { get; set; }
    public string? UomId { get; set; }
    public decimal? TermDays { get; set; }
    public string? TextValue { get; set; }
    public string? Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Quote? Quote { get; set; }
    public TermType? TermType { get; set; }
    public ICollection<QuoteTermAttribute> QuoteTermAttributes { get; set; }
}