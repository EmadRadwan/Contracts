﻿using System;

namespace Domain;

public class WorkEffortInventoryProduced
{
    public string WorkEffortId { get; set; }
    public string InventoryItemId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InventoryItem InventoryItem { get; set; }
    public WorkEffort WorkEffort { get; set; }
}