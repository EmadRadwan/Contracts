﻿using System;

namespace Domain;

public class PartySkill
{
    public string PartyId { get; set; }
    public string SkillTypeId { get; set; }
    public decimal? YearsExperience { get; set; }
    public decimal? Rating { get; set; }
    public decimal? SkillLevel { get; set; }
    public DateTime? StartedUsingDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public SkillType SkillType { get; set; }
}