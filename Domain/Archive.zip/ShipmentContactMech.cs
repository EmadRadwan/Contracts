﻿using System;

namespace Domain;

public class ShipmentContactMech
{
    public string ShipmentId { get; set; }
    public string ShipmentContactMechTypeId { get; set; }
    public string ContactMechId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMech ContactMech { get; set; }
    public Shipment Shipment { get; set; }
    public ShipmentContactMechType ShipmentContactMechType { get; set; }
}