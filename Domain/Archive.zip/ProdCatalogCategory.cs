﻿using System;

namespace Domain;

public class ProdCatalogCategory
{
    public string ProdCatalogId { get; set; }
    public string ProductCategoryId { get; set; }
    public string ProdCatalogCategoryTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProdCatalog ProdCatalog { get; set; }
    public ProdCatalogCategoryType ProdCatalogCategoryType { get; set; }
    public ProductCategory ProductCategory { get; set; }
}