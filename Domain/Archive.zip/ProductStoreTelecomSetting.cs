﻿using System;

namespace Domain;

public class ProductStoreTelecomSetting
{
    public string ProductStoreId { get; set; }
    public string TelecomMethodTypeId { get; set; }
    public string TelecomMsgTypeEnumId { get; set; }
    public string TelecomCustomMethodId { get; set; }
    public string TelecomGatewayConfigId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductStore ProductStore { get; set; }
    public CustomMethod TelecomCustomMethod { get; set; }
    public TelecomGatewayConfig TelecomGatewayConfig { get; set; }
    public TelecomMethodType TelecomMethodType { get; set; }
    public Enumeration TelecomMsgTypeEnum { get; set; }
}