﻿using System;

namespace Domain;

public class PersonTraining
{
    public string PartyId { get; set; }
    public string TrainingRequestId { get; set; }
    public string TrainingClassTypeId { get; set; }
    public string WorkEffortId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string ApproverId { get; set; }
    public string ApprovalStatus { get; set; }
    public string Reason { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Person Approver { get; set; }
    public Party Party { get; set; }
    public TrainingClassType TrainingClassType { get; set; }
    public TrainingRequest TrainingRequest { get; set; }
    public WorkEffort WorkEffort { get; set; }
}