﻿using System;
using System.Collections.Generic;

namespace Domain;

public class PaymentGatewayConfigType
{
    public PaymentGatewayConfigType()
    {
        InverseParentType = new HashSet<PaymentGatewayConfigType>();
        PaymentGatewayConfigs = new HashSet<PaymentGatewayConfig>();
    }

    public string PaymentGatewayConfigTypeId { get; set; }
    public string ParentTypeId { get; set; }
    public string HasTable { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentGatewayConfigType ParentType { get; set; }
    public ICollection<PaymentGatewayConfigType> InverseParentType { get; set; }
    public ICollection<PaymentGatewayConfig> PaymentGatewayConfigs { get; set; }
}