﻿using System;

namespace Domain;

public class ProductFeatureApplAttr
{
    public Guid ProductId { get; set; }
    public string ProductFeatureId { get; set; }
    public DateTime FromDate { get; set; }
    public string AttrName { get; set; }
    public string AttrValue { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
    public ProductFeature ProductFeature { get; set; }
    public ProductFeatureAppl ProductFeatureAppl { get; set; }
}