﻿using System;

namespace Domain;

public class ShipmentTimeEstimate
{
    public string ShipmentMethodTypeId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public string GeoIdTo { get; set; }
    public string GeoIdFrom { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? LeadTime { get; set; }
    public string LeadTimeUomId { get; set; }
    public decimal? SequenceNumber { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CarrierShipmentMethod CarrierShipmentMethod { get; set; }
    public Geo GeoIdFromNavigation { get; set; }
    public Geo GeoIdToNavigation { get; set; }
    public Uom LeadTimeUom { get; set; }
}