﻿using System;

namespace Domain;

public class TechDataCalendarExcWeek
{
    public string CalendarId { get; set; }
    public DateTime ExceptionDateStart { get; set; }
    public string CalendarWeekId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public TechDataCalendar Calendar { get; set; }
    public TechDataCalendarWeek CalendarWeek { get; set; }
}