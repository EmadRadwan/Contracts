﻿using System;

namespace Domain;

public class ReturnItemShipment
{
    public string ReturnId { get; set; }
    public string ReturnItemSeqId { get; set; }
    public string ShipmentId { get; set; }
    public string ShipmentItemSeqId { get; set; }
    public decimal? Quantity { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ReturnHeader Return { get; set; }
    public ReturnItem ReturnI { get; set; }
    public Shipment Shipment { get; set; }
    public ShipmentItem ShipmentI { get; set; }
}