﻿using System;

namespace Domain;

public class ProtectedView
{
    public string GroupId { get; set; }
    public string ViewNameId { get; set; }
    public decimal? MaxHits { get; set; }
    public decimal? MaxHitsDuration { get; set; }
    public decimal? TarpitDuration { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SecurityGroup Group { get; set; }
}