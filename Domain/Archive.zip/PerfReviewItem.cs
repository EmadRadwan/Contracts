﻿using System;

namespace Domain;

public class PerfReviewItem
{
    public string EmployeePartyId { get; set; }
    public string EmployeeRoleTypeId { get; set; }
    public string PerfReviewId { get; set; }
    public string PerfReviewItemSeqId { get; set; }
    public string PerfReviewItemTypeId { get; set; }
    public string PerfRatingTypeId { get; set; }
    public string Comments { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyRole Employee { get; set; }
    public Party EmployeeParty { get; set; }
    public PerfReview PerfReview { get; set; }
}