﻿using System;

namespace Domain;

public class WorkEffortSkillStandard
{
    public string WorkEffortId { get; set; }
    public string SkillTypeId { get; set; }
    public double? EstimatedNumPeople { get; set; }
    public double? EstimatedDuration { get; set; }
    public decimal? EstimatedCost { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SkillType SkillType { get; set; }
    public WorkEffort WorkEffort { get; set; }
}