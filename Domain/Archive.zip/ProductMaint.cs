﻿using System;

namespace Domain;

public class ProductMaint
{
    public Guid ProductId { get; set; }
    public string ProductMaintSeqId { get; set; }
    public string ProductMaintTypeId { get; set; }
    public string MaintName { get; set; }
    public string MaintTemplateWorkEffortId { get; set; }
    public decimal? IntervalQuantity { get; set; }
    public string IntervalUomId { get; set; }
    public string IntervalMeterTypeId { get; set; }
    public decimal? RepeatCount { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductMeterType IntervalMeterType { get; set; }
    public Uom IntervalUom { get; set; }
    public WorkEffort MaintTemplateWorkEffort { get; set; }
    public Product Product { get; set; }
    public ProductMaintType ProductMaintType { get; set; }
}