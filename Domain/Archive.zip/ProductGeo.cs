﻿using System;

namespace Domain;

public class ProductGeo
{
    public Guid ProductId { get; set; }
    public string GeoId { get; set; }
    public string ProductGeoEnumId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Geo Geo { get; set; }
    public Product Product { get; set; }
    public Enumeration ProductGeoEnum { get; set; }
}