﻿using System;

namespace Domain;

public class ShoppingListWorkEffort
{
    public string ShoppingListId { get; set; }
    public string WorkEffortId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ShoppingList ShoppingList { get; set; }
    public WorkEffort WorkEffort { get; set; }
}