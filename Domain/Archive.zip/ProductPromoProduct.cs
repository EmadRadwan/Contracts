﻿using System;

namespace Domain;

public class ProductPromoProduct
{
    public string ProductPromoId { get; set; }
    public string ProductPromoRuleId { get; set; }
    public string ProductPromoActionSeqId { get; set; }
    public string ProductPromoCondSeqId { get; set; }
    public Guid ProductId { get; set; }
    public string ProductPromoApplEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
    public ProductPromo ProductPromo { get; set; }
    public Enumeration ProductPromoApplEnum { get; set; }
}