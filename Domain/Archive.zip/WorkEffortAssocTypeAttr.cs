﻿using System;

namespace Domain;

public class WorkEffortAssocTypeAttr
{
    public string WorkEffortAssocTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffortAssocType WorkEffortAssocType { get; set; }
}