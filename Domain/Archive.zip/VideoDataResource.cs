﻿using System;

namespace Domain;

public class VideoDataResource
{
    public string DataResourceId { get; set; }
    public byte[] VideoData { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public DataResource DataResource { get; set; }
}