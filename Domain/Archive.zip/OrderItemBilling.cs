﻿using System;

namespace Domain;

public class OrderItemBilling
{
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string InvoiceId { get; set; }
    public string InvoiceItemSeqId { get; set; }
    public string ItemIssuanceId { get; set; }
    public string ShipmentReceiptId { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? Amount { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public InvoiceItem InvoiceI { get; set; }
    public ItemIssuance ItemIssuance { get; set; }
    public OrderHeader Order { get; set; }
    public OrderItem OrderI { get; set; }
    public ShipmentReceipt ShipmentReceipt { get; set; }
}