﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ShipmentContactMechType
{
    public ShipmentContactMechType()
    {
        ShipmentContactMeches = new HashSet<ShipmentContactMech>();
    }

    public string ShipmentContactMechTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<ShipmentContactMech> ShipmentContactMeches { get; set; }
}