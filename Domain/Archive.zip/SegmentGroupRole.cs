﻿using System;

namespace Domain;

public class SegmentGroupRole
{
    public string SegmentGroupId { get; set; }
    public string PartyId { get; set; }
    public string RoleTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PartyRole PartyRole { get; set; }
    public SegmentGroup SegmentGroup { get; set; }
}