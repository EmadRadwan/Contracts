﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductFeatureAppl
{
    public ProductFeatureAppl()
    {
        ProductFeatureApplAttrs = new HashSet<ProductFeatureApplAttr>();
    }

    public Guid ProductId { get; set; }
    public string ProductFeatureId { get; set; }
    public string ProductFeatureApplTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public decimal? Amount { get; set; }
    public decimal? RecurringAmount { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
    public ProductFeature ProductFeature { get; set; }
    public ProductFeatureApplType ProductFeatureApplType { get; set; }
    public ICollection<ProductFeatureApplAttr> ProductFeatureApplAttrs { get; set; }
}