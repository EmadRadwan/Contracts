﻿using System;

namespace Domain;

public class ThirdPartyLogin
{
    public string ProductStoreId { get; set; }
    public string LoginMethTypeId { get; set; }
    public string LoginProviderId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductStore ProductStore { get; set; }
}