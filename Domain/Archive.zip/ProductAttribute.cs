﻿using System;

namespace Domain;

public class ProductAttribute
{
    public Guid ProductId { get; set; }
    public string AttrName { get; set; }
    public string AttrValue { get; set; }
    public string AttrType { get; set; }
    public string AttrDescription { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
}