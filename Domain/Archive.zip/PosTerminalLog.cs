﻿using System;

namespace Domain;

public class PosTerminalLog
{
    public string PosTerminalLogId { get; set; }
    public string PosTerminalId { get; set; }
    public string TransactionId { get; set; }
    public decimal? ItemCount { get; set; }
    public string OrderId { get; set; }
    public string ReturnId { get; set; }
    public string UserLoginId { get; set; }
    public string StatusId { get; set; }
    public DateTime? LogStartDateTime { get; set; }
    public DateTime? LogEndDateTime { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Order { get; set; }
    public PosTerminal PosTerminal { get; set; }
    public ReturnHeader Return { get; set; }
    public StatusItem Status { get; set; }
    public PosTerminalInternTx PosTerminalInternTx { get; set; }
}