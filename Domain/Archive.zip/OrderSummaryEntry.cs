﻿using System;

namespace Domain;

public class OrderSummaryEntry
{
    public DateTime EntryDate { get; set; }
    public Guid ProductId { get; set; }
    public string FacilityId { get; set; }
    public decimal? TotalQuantity { get; set; }
    public decimal? GrossSales { get; set; }
    public decimal? ProductCost { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Facility Facility { get; set; }
    public Product Product { get; set; }
}