﻿using System;

namespace Domain;

public class ProductFeatureCategoryAppl
{
    public string ProductCategoryId { get; set; }
    public string ProductFeatureCategoryId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductCategory ProductCategory { get; set; }
    public ProductFeatureCategory ProductFeatureCategory { get; set; }
}