﻿using System;

namespace Domain;

public class VendorProduct
{
    public Guid ProductId { get; set; }
    public string VendorPartyId { get; set; }
    public string ProductStoreGroupId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Product Product { get; set; }
    public ProductStoreGroup ProductStoreGroup { get; set; }
    public Party VendorParty { get; set; }
}