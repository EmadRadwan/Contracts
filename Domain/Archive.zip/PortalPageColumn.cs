﻿using System;

namespace Domain;

public class PortalPageColumn
{
    public string PortalPageId { get; set; }
    public string ColumnSeqId { get; set; }
    public decimal? ColumnWidthPixels { get; set; }
    public decimal? ColumnWidthPercentage { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PortalPage PortalPage { get; set; }
}