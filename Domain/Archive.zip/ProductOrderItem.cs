﻿using System;

namespace Domain;

public class ProductOrderItem
{
    public string OrderId { get; set; }
    public string OrderItemSeqId { get; set; }
    public string EngagementId { get; set; }
    public string EngagementItemSeqId { get; set; }
    public Guid ProductId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public OrderHeader Engagement { get; set; }
    public OrderItem EngagementI { get; set; }
    public OrderHeader Order { get; set; }
    public OrderItem OrderI { get; set; }
    public Product Product { get; set; }
}