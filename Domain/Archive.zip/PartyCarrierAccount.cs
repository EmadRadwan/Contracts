﻿using System;

namespace Domain;

public class PartyCarrierAccount
{
    public string PartyId { get; set; }
    public string CarrierPartyId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string AccountNumber { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party CarrierParty { get; set; }
    public Party Party { get; set; }
}