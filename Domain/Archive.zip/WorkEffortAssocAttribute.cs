﻿using System;

namespace Domain;

public class WorkEffortAssocAttribute
{
    public string WorkEffortIdFrom { get; set; }
    public string WorkEffortIdTo { get; set; }
    public string WorkEffortAssocTypeId { get; set; }
    public DateTime? FromDate { get; set; }
    public string AttrName { get; set; }
    public string AttrValue { get; set; }
    public string AttrDescription { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffortAssoc WorkEffortAssoc { get; set; }
}