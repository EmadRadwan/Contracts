﻿using System;

namespace Domain;

public class PosTerminalState
{
    public string PosTerminalId { get; set; }
    public DateTime OpenedDate { get; set; }
    public DateTime? ClosedDate { get; set; }
    public string StartingTxId { get; set; }
    public string EndingTxId { get; set; }
    public string OpenedByUserLoginId { get; set; }
    public string ClosedByUserLoginId { get; set; }
    public decimal? StartingDrawerAmount { get; set; }
    public decimal? ActualEndingCash { get; set; }
    public decimal? ActualEndingCheck { get; set; }
    public decimal? ActualEndingCc { get; set; }
    public decimal? ActualEndingGc { get; set; }
    public decimal? ActualEndingOther { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PosTerminal PosTerminal { get; set; }
}