﻿using System;

namespace Domain;

public class ProductCostComponentCalc
{
    public Guid ProductId { get; set; }
    public string CostComponentTypeId { get; set; }
    public string CostComponentCalcId { get; set; }
    public DateTime FromDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CostComponentCalc CostComponentCalc { get; set; }
    public CostComponentType CostComponentType { get; set; }
    public Product Product { get; set; }
}