﻿using System;

namespace Domain;

public class ProductStoreCatalog
{
    public string ProductStoreId { get; set; }
    public string ProdCatalogId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProdCatalog ProdCatalog { get; set; }
    public ProductStore ProductStore { get; set; }
}