﻿using System;

namespace Domain;

public class PaymentContent
{
    public string PaymentId { get; set; }
    public string PaymentContentTypeId { get; set; }
    public string ContentId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public Payment Payment { get; set; }
    public PaymentContentType PaymentContentType { get; set; }
}