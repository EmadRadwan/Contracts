﻿using System;

namespace Domain;

public class ProductConfig
{
    public Guid ProductId { get; set; }
    public string ConfigItemId { get; set; }
    public decimal SequenceNum { get; set; }
    public DateTime FromDate { get; set; }
    public string Description { get; set; }
    public string LongDescription { get; set; }
    public string ConfigTypeId { get; set; }
    public string DefaultConfigOptionId { get; set; }
    public DateTime? ThruDate { get; set; }
    public string IsMandatory { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductConfigItem ConfigItem { get; set; }
    public Product Product { get; set; }
}