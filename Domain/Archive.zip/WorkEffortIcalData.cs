﻿using System;

namespace Domain;

public class WorkEffortIcalData
{
    public string WorkEffortId { get; set; }
    public string IcalData { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffort WorkEffort { get; set; }
}