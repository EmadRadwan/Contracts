﻿using System;

namespace Domain;

public class ProductPromoCategory
{
    public string ProductPromoId { get; set; }
    public string ProductPromoRuleId { get; set; }
    public string ProductPromoActionSeqId { get; set; }
    public string ProductPromoCondSeqId { get; set; }
    public string ProductCategoryId { get; set; }
    public string AndGroupId { get; set; }
    public string ProductPromoApplEnumId { get; set; }
    public string IncludeSubCategories { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductCategory ProductCategory { get; set; }
    public ProductPromo ProductPromo { get; set; }
    public Enumeration ProductPromoApplEnum { get; set; }
}