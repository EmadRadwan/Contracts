﻿using System;
using System.Collections.Generic;

namespace Domain;

public class TaxAuthority
{
    public TaxAuthority()
    {
        OrderAdjustments = new HashSet<OrderAdjustment>();
        PartyTaxAuthInfoes = new HashSet<PartyTaxAuthInfo>();
        ProductStores = new HashSet<ProductStore>();
        QuoteAdjustments = new HashSet<QuoteAdjustment>();
        ReturnAdjustments = new HashSet<ReturnAdjustment>();
        TaxAuthorityAssocTaxAuths = new HashSet<TaxAuthorityAssoc>();
        TaxAuthorityAssocToTaxAuths = new HashSet<TaxAuthorityAssoc>();
        TaxAuthorityCategories = new HashSet<TaxAuthorityCategory>();
        TaxAuthorityGlAccounts = new HashSet<TaxAuthorityGlAccount>();
        TaxAuthorityRateProducts = new HashSet<TaxAuthorityRateProduct>();
    }

    public string TaxAuthGeoId { get; set; }
    public string TaxAuthPartyId { get; set; }
    public string RequireTaxIdForExemption { get; set; }
    public string TaxIdFormatPattern { get; set; }
    public string IncludeTaxInPrice { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Geo TaxAuthGeo { get; set; }
    public Party TaxAuthParty { get; set; }
    public ICollection<OrderAdjustment> OrderAdjustments { get; set; }
    public ICollection<PartyTaxAuthInfo> PartyTaxAuthInfoes { get; set; }
    public ICollection<ProductStore> ProductStores { get; set; }
    public ICollection<QuoteAdjustment> QuoteAdjustments { get; set; }
    public ICollection<ReturnAdjustment> ReturnAdjustments { get; set; }
    public ICollection<TaxAuthorityAssoc> TaxAuthorityAssocTaxAuths { get; set; }
    public ICollection<TaxAuthorityAssoc> TaxAuthorityAssocToTaxAuths { get; set; }
    public ICollection<TaxAuthorityCategory> TaxAuthorityCategories { get; set; }
    public ICollection<TaxAuthorityGlAccount> TaxAuthorityGlAccounts { get; set; }
    public ICollection<TaxAuthorityRateProduct> TaxAuthorityRateProducts { get; set; }
}