﻿using System;

namespace Domain;

public class ProductStorePromoAppl
{
    public string ProductStoreId { get; set; }
    public string ProductPromoId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public string ManualOnly { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductPromo ProductPromo { get; set; }
    public ProductStore ProductStore { get; set; }
}