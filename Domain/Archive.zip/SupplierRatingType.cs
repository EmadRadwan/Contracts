﻿using System;
using System.Collections.Generic;

namespace Domain;

public class SupplierRatingType
{
    public SupplierRatingType()
    {
        SupplierProducts = new HashSet<SupplierProduct>();
    }

    public string SupplierRatingTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<SupplierProduct> SupplierProducts { get; set; }
}