﻿using System;

namespace Domain;

public class ProductFacility
{
    public Guid ProductId { get; set; }
    public string FacilityId { get; set; }
    public decimal? MinimumStock { get; set; }
    public decimal? ReorderQuantity { get; set; }
    public decimal? DaysToShip { get; set; }
    public string? ReplenishMethodEnumId { get; set; }
    public decimal? LastInventoryCount { get; set; }
    public string? RequirementMethodEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Facility? Facility { get; set; }
    public Product? Product { get; set; }
    public Enumeration? ReplenishMethodEnum { get; set; }
    public Enumeration? RequirementMethodEnum { get; set; }
}