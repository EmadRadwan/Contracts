﻿using System;

namespace Domain;

public class ShipmentItemFeature
{
    public string ShipmentId { get; set; }
    public string ShipmentItemSeqId { get; set; }
    public string ProductFeatureId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductFeature ProductFeature { get; set; }
    public ShipmentItem ShipmentI { get; set; }
}