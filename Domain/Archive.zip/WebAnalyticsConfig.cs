﻿using System;

namespace Domain;

public class WebAnalyticsConfig
{
    public string WebSiteId { get; set; }
    public string WebAnalyticsTypeId { get; set; }
    public string WebAnalyticsCode { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
}