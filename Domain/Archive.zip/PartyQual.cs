﻿using System;

namespace Domain;

public class PartyQual
{
    public string PartyId { get; set; }
    public string PartyQualTypeId { get; set; }
    public string QualificationDesc { get; set; }
    public string Title { get; set; }
    public string StatusId { get; set; }
    public string VerifStatusId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public PartyQualType PartyQualType { get; set; }
    public StatusItem Status { get; set; }
    public StatusItem VerifStatus { get; set; }
}