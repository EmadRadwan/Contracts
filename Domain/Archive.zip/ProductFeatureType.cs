﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductFeatureType
{
    public ProductFeatureType()
    {
        InverseParentType = new HashSet<ProductFeatureType>();
        ProductFeatures = new HashSet<ProductFeature>();
    }

    public string ProductFeatureTypeId { get; set; }
    public string? ParentTypeId { get; set; }
    public string? HasTable { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductFeatureType? ParentType { get; set; }
    public ICollection<ProductFeatureType> InverseParentType { get; set; }
    public ICollection<ProductFeature> ProductFeatures { get; set; }
}