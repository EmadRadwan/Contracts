﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductPriceActionType
{
    public ProductPriceActionType()
    {
        ProductPriceActions = new HashSet<ProductPriceAction>();
    }

    public string ProductPriceActionTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<ProductPriceAction> ProductPriceActions { get; set; }
}