﻿using System;

namespace Domain;

public class SubscriptionFulfillmentPiece
{
    public string SubscriptionActivityId { get; set; }
    public string SubscriptionId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Subscription Subscription { get; set; }
    public SubscriptionActivity SubscriptionActivity { get; set; }
}