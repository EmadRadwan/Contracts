﻿using System;

namespace Domain;

public class ProductStoreKeywordOvrd
{
    public string ProductStoreId { get; set; }
    public string Keyword { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string Target { get; set; }
    public string TargetTypeEnumId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductStore ProductStore { get; set; }
    public Enumeration TargetTypeEnum { get; set; }
}