﻿using System;

namespace Domain;

public class SurveyTrigger
{
    public string SurveyId { get; set; }
    public string SurveyApplTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Survey Survey { get; set; }
    public SurveyApplType SurveyApplType { get; set; }
}