﻿using System;

namespace Domain;

public class ProductAverageCost
{
    public string ProductAverageCostTypeId { get; set; }
    public string OrganizationPartyId { get; set; }
    public Guid ProductId { get; set; }
    public string FacilityId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? AverageCost { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Facility Facility { get; set; }
    public Party OrganizationParty { get; set; }
    public Product Product { get; set; }
    public ProductAverageCostType ProductAverageCostType { get; set; }
}