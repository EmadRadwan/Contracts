﻿using System;

namespace Domain;

public class PartyContactMech
{
    public string PartyId { get; set; }
    public string ContactMechId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public string RoleTypeId { get; set; }
    public string? AllowSolicitation { get; set; }
    public string? Extension { get; set; }
    public string? Verified { get; set; }
    public string? Comments { get; set; }
    public decimal? YearsWithContactMech { get; set; }
    public decimal? MonthsWithContactMech { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMech ContactMech { get; set; }
    public Party Party { get; set; }
    public PartyRole PartyRole { get; set; }
    public RoleType RoleType { get; set; }
}