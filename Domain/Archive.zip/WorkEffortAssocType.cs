﻿using System;
using System.Collections.Generic;

namespace Domain;

public class WorkEffortAssocType
{
    public WorkEffortAssocType()
    {
        InverseParentType = new HashSet<WorkEffortAssocType>();
        WorkEffortAssocTypeAttrs = new HashSet<WorkEffortAssocTypeAttr>();
        WorkEffortAssocs = new HashSet<WorkEffortAssoc>();
    }

    public string WorkEffortAssocTypeId { get; set; }
    public string ParentTypeId { get; set; }
    public string HasTable { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public WorkEffortAssocType ParentType { get; set; }
    public ICollection<WorkEffortAssocType> InverseParentType { get; set; }
    public ICollection<WorkEffortAssocTypeAttr> WorkEffortAssocTypeAttrs { get; set; }
    public ICollection<WorkEffortAssoc> WorkEffortAssocs { get; set; }
}