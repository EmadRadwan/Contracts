﻿using System;

namespace Domain;

public class ProductStoreGroupRollup
{
    public string ProductStoreGroupId { get; set; }
    public string ParentGroupId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductStoreGroup ParentGroup { get; set; }
    public ProductStoreGroup ProductStoreGroup { get; set; }
}