﻿using System;

namespace Domain;

public class WorkEffortCostCalc
{
    public string WorkEffortId { get; set; }
    public string CostComponentTypeId { get; set; }
    public string CostComponentCalcId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public CostComponentCalc CostComponentCalc { get; set; }
    public CostComponentType CostComponentType { get; set; }
    public WorkEffort WorkEffort { get; set; }
}