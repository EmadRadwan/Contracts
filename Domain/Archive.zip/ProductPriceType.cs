﻿using System;
using System.Collections.Generic;

namespace Domain;

public class ProductPriceType
{
    public ProductPriceType()
    {
        ProductFeaturePrices = new HashSet<ProductFeaturePrice>();
        ProductPrices = new HashSet<ProductPrice>();
    }

    public string ProductPriceTypeId { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ICollection<ProductFeaturePrice> ProductFeaturePrices { get; set; }
    public ICollection<ProductPrice> ProductPrices { get; set; }
}