﻿using System;

namespace Domain;

public class PaymentGatewayFirstData
{
    public string PaymentGatewayConfigId { get; set; }
    public string AppName { get; set; }
    public string ApiKey { get; set; }
    public string ApiSecret { get; set; }
    public string TransactionUrl { get; set; }
    public string EnableDataVault { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentGatewayConfig PaymentGatewayConfig { get; set; }
}