﻿using System;

namespace Domain;

public class UserPreference
{
    public string UserLoginId { get; set; }
    public string UserPrefTypeId { get; set; }
    public string UserPrefGroupTypeId { get; set; }
    public string UserPrefValue { get; set; }
    public string UserPrefDataType { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public UserPrefGroupType UserPrefGroupType { get; set; }
}