﻿using System;

namespace Domain;

public class PartyContactMechPurpose
{
    public string PartyId { get; set; }
    public string ContactMechId { get; set; }
    public string ContactMechPurposeTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMech ContactMech { get; set; }
    public ContactMechPurposeType ContactMechPurposeType { get; set; }
    public Party Party { get; set; }
}