﻿using System;

namespace Domain;

public class ShipmentTypeAttr
{
    public string ShipmentTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ShipmentType ShipmentType { get; set; }
}