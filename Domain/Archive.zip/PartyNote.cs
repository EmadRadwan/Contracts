﻿using System;

namespace Domain;

public class PartyNote
{
    public string PartyId { get; set; }
    public string NoteId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public NoteData Note { get; set; }
    public Party Party { get; set; }
}