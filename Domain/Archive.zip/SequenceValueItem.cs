﻿using System;

namespace Domain;

public class SequenceValueItem
{
    public string SeqName { get; set; }
    public decimal? SeqId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }
}