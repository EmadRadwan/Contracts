﻿using System;

namespace Domain;

public class QuoteTypeAttr
{
    public string QuoteTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public QuoteType QuoteType { get; set; }
}