﻿using System;

namespace Domain;

public class PaymentGroupMember
{
    public string PaymentGroupId { get; set; }
    public string PaymentId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Payment Payment { get; set; }
    public PaymentGroup PaymentGroup { get; set; }
}