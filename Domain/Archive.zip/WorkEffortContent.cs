﻿using System;

namespace Domain;

public class WorkEffortContent
{
    public string WorkEffortId { get; set; }
    public string ContentId { get; set; }
    public string WorkEffortContentTypeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Content Content { get; set; }
    public WorkEffort WorkEffort { get; set; }
    public WorkEffortContentType WorkEffortContentType { get; set; }
}