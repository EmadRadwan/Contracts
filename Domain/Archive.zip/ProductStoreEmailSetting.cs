﻿using System;

namespace Domain;

public class ProductStoreEmailSetting
{
    public string ProductStoreId { get; set; }
    public string EmailType { get; set; }
    public string BodyScreenLocation { get; set; }
    public string XslfoAttachScreenLocation { get; set; }
    public string FromAddress { get; set; }
    public string CcAddress { get; set; }
    public string BccAddress { get; set; }
    public string Subject { get; set; }
    public string ContentType { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Enumeration EmailTypeNavigation { get; set; }
    public ProductStore ProductStore { get; set; }
}