﻿using System;

namespace Domain;

public class SalesOpportunityTrckCode
{
    public string SalesOpportunityId { get; set; }
    public string TrackingCodeId { get; set; }
    public DateTime? ReceivedDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public SalesOpportunity SalesOpportunity { get; set; }
}