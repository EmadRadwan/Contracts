﻿using System;

namespace Domain;

public class WorkEffortSurveyAppl
{
    public string WorkEffortId { get; set; }
    public string SurveyId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductStoreSurveyAppl Survey { get; set; }
    public Survey SurveyNavigation { get; set; }
    public WorkEffort WorkEffort { get; set; }
}