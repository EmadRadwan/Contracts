﻿using System;

namespace Domain;

public class PaymentGatewayRespMsg
{
    public string PaymentGatewayRespMsgId { get; set; }
    public string PaymentGatewayResponseId { get; set; }
    public string PgrMessage { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentGatewayResponse PaymentGatewayResponse { get; set; }
}