﻿using System;

namespace Domain;

public class RespondingParty
{
    public string RespondingPartySeqId { get; set; }
    public string CustRequestId { get; set; }
    public string PartyId { get; set; }
    public string ContactMechId { get; set; }
    public DateTime? DateSent { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMech ContactMech { get; set; }
    public CustRequest CustRequest { get; set; }
    public Party Party { get; set; }
}