﻿using System;

namespace Domain;

public class ValidContactMechRole
{
    public string RoleTypeId { get; set; }
    public string ContactMechTypeId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMechType ContactMechType { get; set; }
    public RoleType RoleType { get; set; }
}