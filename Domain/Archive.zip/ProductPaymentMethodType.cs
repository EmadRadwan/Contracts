﻿using System;

namespace Domain;

public class ProductPaymentMethodType
{
    public Guid ProductId { get; set; }
    public string PaymentMethodTypeId { get; set; }
    public string ProductPricePurposeId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public decimal? SequenceNum { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public PaymentMethodType PaymentMethodType { get; set; }
    public Product Product { get; set; }
    public ProductPricePurpose ProductPricePurpose { get; set; }
}