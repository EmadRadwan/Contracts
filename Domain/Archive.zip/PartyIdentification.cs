﻿using System;

namespace Domain;

public class PartyIdentification
{
    public string PartyId { get; set; }
    public string PartyIdentificationTypeId { get; set; }
    public string IdValue { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public Party Party { get; set; }
    public PartyIdentificationType PartyIdentificationType { get; set; }
}