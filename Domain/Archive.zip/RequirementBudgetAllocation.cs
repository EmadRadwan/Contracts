﻿using System;

namespace Domain;

public class RequirementBudgetAllocation
{
    public string BudgetId { get; set; }
    public string BudgetItemSeqId { get; set; }
    public string RequirementId { get; set; }
    public decimal? Amount { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public BudgetItem BudgetI { get; set; }
    public Requirement Requirement { get; set; }
}