﻿using System;

namespace Domain;

public class ProductCategoryTypeAttr
{
    public string ProductCategoryTypeId { get; set; }
    public string AttrName { get; set; }
    public string Description { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ProductCategoryType ProductCategoryType { get; set; }
}