using System;
using Microsoft.AspNetCore.Identity;

namespace Domain;

public class SecurityGroupPermission : IdentityRoleClaim<string>
{
    public string GroupId { get; set; }
    public string PermissionId { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime? ThruDate { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    // IdentityRoleClaim
    // Id
    // RoleId
    // ClaimType
    // ClaimValue

    public SecurityGroup Group { get; set; }
}