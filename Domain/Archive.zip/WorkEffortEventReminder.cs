﻿using System;

namespace Domain;

public class WorkEffortEventReminder
{
    public string WorkEffortId { get; set; }
    public string SequenceId { get; set; }
    public string ContactMechId { get; set; }
    public string PartyId { get; set; }
    public DateTime? ReminderDateTime { get; set; }
    public decimal? RepeatCount { get; set; }
    public decimal? RepeatInterval { get; set; }
    public decimal? CurrentCount { get; set; }
    public decimal? ReminderOffset { get; set; }
    public string LocaleId { get; set; }
    public string TimeZoneId { get; set; }
    public DateTime? LastUpdatedStamp { get; set; }
    public DateTime? CreatedStamp { get; set; }

    public ContactMech ContactMech { get; set; }
    public Party Party { get; set; }
    public WorkEffort WorkEffort { get; set; }
}