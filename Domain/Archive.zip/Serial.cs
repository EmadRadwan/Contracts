﻿namespace Domain;

public class Serial
{
    public string Id { get; set; }
    public string CustomerRequestInitial { get; set; }
    public int CustomerRequestLastUsedSerial { get; set; }
    public string CustomerQuoteInitial { get; set; }
    public int CustomerQuoteLastUsedSerial { get; set; }
}